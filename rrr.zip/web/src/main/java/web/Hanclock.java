package web;

import java.util.Timer;
import java.util.TimerTask;
import java.time.*;

public class Hanclock {

	protected String[][] showHourMinutes;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hanclock clock=new Hanclock();
		Timer sceduler=new Timer();
		
		TimerTask time =new TimerTask() {
			@Override
			public void run() {
				String clockresult[][]=clock.showHourMinutes;
			}
		};
		
	}
}
