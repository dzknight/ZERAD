package javawin1;

public class mon54321 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0;i<6;i++) {
			//for(int j=6;j>i;j--) {
			for(int j=0;j<5-i;j++) {
				System.out.print("*");
			}
			System.out.println("");
		}
	}

}
