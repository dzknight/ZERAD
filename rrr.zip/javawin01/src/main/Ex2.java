package main;

import java.util.Random;
import java.util.Scanner;

public class Ex2  {
	static int [] lottoNum=new int[6];
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("시작");
		Scanner in=new Scanner(System.in);
		System.out.println("로또 반복 횟수");
		
		for(int i=0;i<5;i++) {
			randomInt();//콜 실행 리턴
			prtLotto();
		}
	}
	public static void randomInt() {
		Random r=new Random();
		for(int i=0;i<lottoNum.length;i++) {
			int k=r.nextInt(45)+1;
			int flag=checkDupl(k);
			if(flag != -1) {
				i--;//불린 타입 조건문
			} else {
				lottoNum[i]=k;
			}
		}
	}
	public static int checkDupl(int a) {
		
		for(int i=0;i<lottoNum.length;i++) {
			if(lottoNum[i]==a) {
				//중복되는 경우
				return i;
			}
		}
		return -1;
	}
	public static void prtLotto() {
		for(int i=0;i<lottoNum.length;i++) {
			System.out.print(lottoNum[i]+" ");
		}
		System.out.println();
	}

}
