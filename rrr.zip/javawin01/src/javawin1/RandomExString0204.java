package javawin1;
import java.util.Scanner;
public class RandomExString0204 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		while(true) {
			System.out.println("type name");
			String name=in.next();

			System.out.println("type name is"+name);
			System.out.println("type length"+name.length());
			System.out.println("type age");
			int age=in.nextInt();
			System.out.println("type age"+age);
			System.out.println("type hobby");
			String hobby=in.next();
		//	in.nextLine();//buffer initiating
			System.out.println("취미"+hobby);
			
			
			
		}
		
	}

}
