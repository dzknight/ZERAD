package mainOne;

public class CarOne {
	String num;
	String userName;
}
