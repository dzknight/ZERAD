package EventM;

public class User {
	String id=null;
	String name=null;
	String addr=null;
	boolean adult =true;
	public User(String id,String name,String addr) {
		this.id=id;
		this.name=name;
		this.addr=addr;
		
	}
	//해당메서드를 통해 멤버변수에 접근
	public void prtUser() {
		System.out.println("id: "+id);
		System.out.println("name: "+name);
		System.out.println("addr: "+addr);
	}
}
