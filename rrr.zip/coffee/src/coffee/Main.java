package coffee;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		startMenu start=new startMenu();
		System.out.println("프로그램을 시작합니다");
		start.startMenu();//객체의 주소참조하여 스타트메뉴 호출
		
	}

}
