package javawin1;

public class array49 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*int[] a ={34,55,23,56,34,45,34};
		int[] b ={36,49};

		출력은
		 a 배열의 값에는  36번호 보다 큰 숫자가 ?? 개 있습니다.
		 a 배열의 값에는  49번호 보다 큰 숫자가 ?? 개 있습니다.
		 */
		int[] a ={34,55,23,56,34,45,34};
		int[] b ={36,49};
		int count36 =0;
		int count49 =0;
		for(int j=0;j<2;j++) {
			for(int i=0;i<7;i++) {
					if(a[i]>b[0]) {
						count36=count36+1;
						System.out.println(a[i]);
					} 
					if(a[i]>b[1]) {
						count49=count49+1;
					}
			}
		}
		System.out.println( "a 배열의 값에는  36번호 보다 큰 숫자가"+count36/2+"개 있습니다.");
		System.out.println( "a 배열의 값에는  49번호 보다 큰 숫자가"+count49/2+"개 있습니다.");
	}

}
