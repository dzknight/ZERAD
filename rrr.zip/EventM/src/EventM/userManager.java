package EventM;

import java.util.Scanner;

public class userManager {
	User[] userlist=new User[5];
	
	public void start() {
		Scanner in=new Scanner(System.in);
		while(true) {
			menu();
			System.out.println("선택");
			int a=in.nextInt();
			in.nextLine();
			if(a==1) {
				add();
			}else if(a==2) {
				showAll();
			} else {
				break;
			}
		}
		in.close();
	}

	private void showAll() {
		// TODO Auto-generated method stub
		for(int i=0;i<userlist.length;i++) {
			if(userlist!=null) {
				userlist[i].prtUser();
			}
		}
	}

	private void add() {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);

		//아이디가 중복이 업다면 폴스
		//중복아이디라면 트루
		
		System.out.println("사용자추가입니다");
		System.out.println("아이디입력");
		String id=in.nextLine();
		System.out.println("이름입력");
		String name=in.nextLine();
		System.out.println("주소입력");
		String addr=in.nextLine();
		User user=new User(id,name,addr);

		//유저리스트가 비어있으면 회원추가
		for(int i=0;i<userlist.length;i++) {
			if(userlist==null) {
				userlist[i]=user;
				break;
			}
		}
	
	}

	private void menu() {
		// TODO Auto-generated method stub
		System.out.println("1.추가");
		System.out.println("2.전체보기");
//		System.out.println("3.삭제");
//		System.out.println("4.변경");
//		System.out.println("5.검색");
	}
}
