package javawin1;

public class fac00 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		int f=1;
		for(int i=1;i<10;i++) {
			f=1;
			for(int j=i;j>=1;j--) {
				f=f*j;
			}
			sum=sum+f;
		}
		System.out.println(sum);
	}

}
