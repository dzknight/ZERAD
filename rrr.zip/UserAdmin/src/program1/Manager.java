package program1;

import java.util.HashMap;
import java.util.Scanner;

public class Manager extends Event {
	static HashMap manager = new HashMap<>();
	static HashMap event = new HashMap<>();
	   
	public static void main(String[] args) {
	
	Scanner sc =new Scanner(System.in);
	String eventName=null;//스캐너 입력 변수
	int eventId=event.size();
	manager.put("김자바", 1);
	manager.put("이가나", 2);
	manager.put("이이이", 3);
	manager.put("가나다", 4);
	event.put("수영", 1);
	event.put("자바", 2);
	event.put("축구", 3);
	event.put("야구", 4);
	System.out.println("매니저목록"+manager.toString());
	System.out.println("이벤트목록"+event.toString());
	while(true) {
		menu();
		String select=sc.nextLine();
		switch(select) {
		case "1":
			System.out.println("이벤트 등록");
			System.out.println("이벤트 이름을 입력하세요");
			eventName=sc.nextLine();
			if(event.containsKey(eventName)) {
				System.out.println("사용중입니다");
			} else{ 
				event.containsKey(eventName);
				event.put(eventName, eventId+1);
				System.out.println(eventName+"등록되었습니다");
				//System.out.println(event.entrySet());
			}
			break;
		case "2":
			System.out.println("이벤트 전체보기");
			System.out.println(event.toString());
			break;
		case "3":
			System.out.println("이벤트 삭제");
			System.out.println("삭제할 이벤트 이름을 입력하세요");
			eventName=sc.nextLine();
			event.remove(eventName);
			System.out.println("삭제되었습니다");
			break;
		case "4":
			System.out.println("이벤트 수정");
			System.out.println("수정될 이벤트 이름을 입력하세요");
			eventName=sc.nextLine();
			System.out.println("수정할 이벤트 이름을 입력하세요");
			String eventName1=sc.nextLine();
			event.replace(eventName,eventName1);
			System.out.println(eventName+"에서"+eventName1+"로 변경되었습니다");
			break;
		case "5":
			System.out.println("이벤트 검색");
			System.out.println("검색할 이벤트 이름을 입력하세요");
			eventName=sc.nextLine();
			if(!event.containsKey(eventName)) {
				System.out.println("검색결과는 존재하지않습니다");
			} else if(event.containsKey(eventName)) {
				System.out.println("검색결과는"+eventName);
			}
		}
		break; 
		
	}
}
	public static void menu() {
		//Scanner sc =new Scanner(System.in);
		System.out.println("1.이벤트 등록");
		System.out.println("2.이벤트 전체보기");
		System.out.println("3.이벤트 삭제");
		System.out.println("4.이벤트 수정");
		System.out.println("5.이벤트 검색");
		//String select=sc.nextLine();
	}
}
