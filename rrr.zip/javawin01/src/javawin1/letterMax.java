package javawin1;

public class letterMax {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] letter={8,12,4,13,2,14,4,5};
		int max=0;
		for(int i=0;i<8;i++) {
			if(letter[i]>i) {
				max=i;
				//letter[max]=letter[i];
			}
		}
		System.out.println(max);
	}

}
