package main;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class fileEx {

	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		FileInputStream fis = new FileInputStream("src/main/text.txt");
		
		int data = 0;
		
		while((data=fis.read())!=-1) { // 한글자씩 불러오기
			System.out.println((char)data);
		}
		
	    	//파일을 다시 읽을 때 객체 다시 생성
		fis = new FileInputStream("src/main/text.txt");
		
		byte[] buf = new byte[fis.available()];

		while((data=fis.read(buf,0,buf.length))!= -1) { // 전체 읽어오기
			System.out.println(new String(buf,0,data));
			System.out.println("end--------------------------------------");
		}
	    	fis.close();
		
	}

}
