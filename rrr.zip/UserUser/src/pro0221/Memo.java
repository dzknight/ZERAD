package pro0221;

public class Memo {
	String title=null;
	String content=null;
	public void prt() {
		System.out.println("제목" +title);
		System.out.println("내용" +content);
	}
	public void setdata(String title,String content) {
		this.content=content;
		this.title=title;
	}
}
