package TestCode;

import java.util.ArrayList;
import java.util.List;

public class Member {
	private String id;
	private String pw;
	private String name;
	private String jubun;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Member> mbrList=new ArrayList<>();
		mbrList.add(new Member("yuyu","yuyu","유재석","yuyu"));
	}
	
	public Member(String id,String pw,String name,String jubun) {
		this.id=id;
		this.pw=pw;
		this.name=name;
		this.jubun=jubun;
	}
	
	
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getJubun() {
		return jubun;
	}

	public void setJubun(String jubun) {
		this.jubun = jubun;
	}

}
