package javawin1;

public class ex36 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0;i<3;i++) {
			for(int j=0;j<6;j++) {
				System.out.print("*");
			}
			System.out.println("");
		}
	}

}
