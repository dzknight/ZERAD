package main;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [][]a = { 
				{2, 4, 1, 2, 1},
				{3, 4, 2, 3, 3},
				{2, 4, 1, 2, 2},
				{4, 4, 4, 1, 2},
				{4, 2, 3, 3, 2}
				};
		/*
		System.out.println(a[0][1]);
		System.out.println(a[1][1]);
		System.out.println(a[2][1]);
		System.out.println(a[3][1]);
		
		System.out.println(a[3][0]);
		System.out.println(a[3][1]);
		System.out.println(a[3][2]);
		
		System.out.println(a[2][4]);
		System.out.println(a[3][4]);
		System.out.println(a[4][4]);
		*/
		/*
		System.out.println("1행출력");
		for(int i=3;i==3;i++) {
			for(int j=0;j<5;j++) {
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}
		
		System.out.println("열출력");
		for(int i=0;i<5;i++) {
			for(int j=1;j==1;j++) {
				System.out.print(a[i][j]+" ");
			}
			for(int j=4;j==4;j++) {
				System.out.print(a[i][j]+" ");
			}
			
		}
		System.out.println();*/
		//전체배열출력	j,x로
		
		for(int i=0;i<5;i++) {
			for(int j=0;j<5;j++) {
				System.out.print(a[j][i]+" ");
			}
			System.out.println();
		}
		
		
	}

}
