package main.copy;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CarM carm =new CarM(); 
		
		Scanner in=new Scanner(System.in);
		//자동차
		boolean flag=true;
		while(flag) {
			System.out.println("1.자동차관리");
			System.out.println("2.수리관리");
			int a=in.nextInt();
			in.nextLine();
			switch(a) {
			case 1: carm.menu(); break;
			case 2: 
				System.out.println("수리할차번호입력");
				String carnum=in.nextLine();
				CarOne list[] =carm.getCarList();
				for(CarOne c :list) {
					//extended for 
					if(c!=null) {
						if(c.getNum().equals(carnum)) {
							//수리할 자동차를 찾을것
							System.out.println("다음정보의 차를 찾았습니다!");
							c.prt();
							c.menu();
						}
					}
				}
				break;
			default: flag=false;
			}
		}
	}

}
