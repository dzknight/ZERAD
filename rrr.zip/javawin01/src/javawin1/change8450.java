package javawin1;

public class change8450 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		/*987654321이라는 숫자가 있다.. 변수2개와 for문 한개로
		   모든 자릿수를 더한 합을 */
		
		int money=10000;
		int pay=8450;
		
		int sum=0;
		int change=money-pay;
		
		for (int i=0;i<=change;i++) {
		}
		System.out.println("천원갯수는"+change/1000+"백원갯수는"+change%1000/100+"십원갯수는"+change%1000%100/10);
	}
	}

