package javawin1;

public class array01 {

	public static  void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a =new int[4];
		System.out.println("length"+a.length);
		System.out.println("초기값"+a[0]);

		a[0] = 40;
		a[3] = 60;
		a[4] = 70;
		System.out.println(a[0]+"/"+a[1]+"/"+a[02]+"/"+a[3]);
		System.out.print("tets");
		//배열의인덱스 범위가 넘어서면 예외 발생
		a[4] = 70;
/*
 * 배열은 연속적으로 할당 고정길이
 * 참조변수명 길이 밸류를 먼저 분석한다
 * 
 * 
 * 
 * */
		
		
	}

}
