package javawin1;

public class printf0121 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int[] a = new int[5];
		 for(int i=0;i<5;i++) {
				 a[i]=10+i;
		 }
		 for(int i=0;i<5;i++) {
			 System.out.println(a[i]);
		 }
	
	}

}
