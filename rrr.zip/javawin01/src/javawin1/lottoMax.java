package javawin1;

public class lottoMax {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] lotto = {6,12,33,4,5,26} ;
		int max=0;
		if(lotto[0]>max) {
			max=lotto[0];
		}
		if(lotto[1]>max) {
			max=lotto[1];
		}
		if(lotto[2]>max) {
			max=lotto[2];
		}
		if(lotto[3]>max) {
			max=lotto[3];
		}
		if(lotto[4]>max) {
			max=lotto[4];
		}
		if(lotto[5]>max) {
			max=lotto[5];
		}
		lotto[5]=max;
		System.out.println(max);
	}

}
