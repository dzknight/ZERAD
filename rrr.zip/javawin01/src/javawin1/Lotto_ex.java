package javawin1;
import java.util.Scanner;
import java.util.Random;

public class Lotto_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random r=new Random();
		/*Random r=new Random();
		int a=r.nextInt(100);
		r.nextInt(100); 
		for(int i=0;i<10;i++) {
		//System.out.println(r.nextInt(5)+1);
		//테스트 결과 값을 추출하는 번호는 r.nextInt(45)+1로 추출할수 있다
		/*
		int[] lotto=new int[7];
		//배열 샘플 저장하는 테스트 코드
		for(int i=0;i<7;i++) {
			System.out.println(i+"|"+lotto[i]);
			
		}*/
		//로또 번호를 뽑아서 변수에 저장
		int[] lotto=new int[7];
		int a=r.nextInt(45)+1;
		lotto[0]=a;
		for(int i=0;i<7;i++) {
			int b=r.nextInt(45)+1;
			lotto[i]=b;
		}
		for(int i=0;i<7;i++) {
			System.out.println(lotto[i]);
		}
		
	}
		
	
	}


