package study;

import java.util.HashMap;

public class SingletonHashMap {
	    // 싱글톤 인스턴스
	    private static SingletonHashMap instance;

	    // HashMap 데이터 저장
	    private HashMap<String, String> dataMap;

	    // private 생성자
	    private SingletonHashMap() {
	        dataMap = new HashMap<>(); // HashMap 초기화
	    }

	    // 싱글톤 인스턴스를 반환하는 메서드
	    public static SingletonHashMap getInstance() {
	        if (instance == null) {
	            synchronized (SingletonHashMap.class) { // 멀티스레드 환경 고려
	                if (instance == null) {
	                    instance = new SingletonHashMap();
	                }
	            }
	        }
	        return instance;
	    }

	    // 데이터를 추가하는 메서드
	    public void putData(String key, String value) {
	        dataMap.put(key, value);
	    }

	    // 데이터를 가져오는 메서드
	    public String getData(String key) {
	        return dataMap.get(key);
	    }

	    // 전체 데이터를 반환하는 메서드 (선택 사항)
	    public HashMap<String, String> getAllData() {
	        return dataMap;
	    }
	}

