package javawin1;

public class Day02_01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char a='A';
		int b =65;
		
		System.out.println(a);
		System.out.println(b);
		a++;
		b++;
		System.out.println((int)a);
		//형변환 int
		System.out.println((char)b);
		//형변환 char
	}

}
