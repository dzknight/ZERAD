package javawin1;

public class countiEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		for(int i=0;i<10;i++) {
			//sum=sum+i; //55
			if(i%3==0) {
				break;//sum0
				/*컨티뉴를 만나면 더이상 코드를 실행하지 않고 조건으로 이동 
				 * 증감식은 동작*/
			}
			sum=sum+i;
		}
		System.out.println(sum);
	}

}
