package user;

public class User {
	String id=null;
	String name=null;
	User(String id,String name){
		this.id=id;//자기자신의 멤버변수
		this.name=name;
	}
}
