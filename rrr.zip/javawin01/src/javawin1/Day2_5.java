package javawin1;

public class Day2_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int pJava=50;
		int pDb=80;
		
		//boolean test = pJava >=60;
		boolean test1 = pDb >= 80 == pJava >=60;
		System.out.println(test1);
	}

}
