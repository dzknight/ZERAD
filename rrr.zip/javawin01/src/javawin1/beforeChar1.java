package javawin1;

public class beforeChar1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char beforeChar='a';
		char afterChar='^';
		beforeChar++;
		beforeChar++;
		
		afterChar=beforeChar;
		System.out.println(afterChar);
		
		
	}

}
