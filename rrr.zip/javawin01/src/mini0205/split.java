package mini0205;

public class split {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "ABCDEFG"; 
		str.substring(3);//test
		System.out.println(str.substring(3,4));
		String inid ="human!";
	}

}
