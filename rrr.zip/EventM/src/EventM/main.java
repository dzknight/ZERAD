package EventM;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		userManager usermanager=null;
		//객체 저장
		usermanager=new userManager();
		//객체 직접 생성
		usermanager.start();
	}

}
