package study;



public class MainRetri {

	public static void main(String[] args) {
		UserM userM = new UserM();
		
		System.out.println("프로그램을 시작합니다");
		userM.menu();
		DataAdder adder=new DataAdder();
		adder.addData();
		DataRetriever retriever=new DataRetriever();
		retriever.retrieveData();
	}

}
