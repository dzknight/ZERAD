package javawin1;
import java.util.Random;

public class test22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr=new int[10];
		//배열생성
	Random rd =new Random();
	for(int i=0;i<arr.length;i++) {
		arr[i]=rd.nextInt(100)+1;
	}
	int max=arr[0];
	int min=arr[0];
	
	for(int a=1;a<arr.length;a++) {
		if(max<arr[a]) {
			max=arr[a];
		}
		if(arr[a]<min) {
			min=arr[a];
		}
	}
	System.out.println(max);
	System.out.println(min);
	}

}
