package javawin1;

public class no04_build {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {1,0,0,0,1,1,1,0,0,0,0,1,1,1,1,0,0,0,1};
		int cnt=0;
		int check1=0;
	//System.out.println("배열의 인덱스"+arr.length);
		for(int i=0;i<arr.length;i++) {
				check1=0;//
				for(int j=i+1; j<i+2;j++) {//검색범위
					if(arr[i]!=arr[j] ||arr[j]==1 ) {
						check1=1;
						break;
						//터널에서 1이 나오거나 현재값과 다음값이 같지 않을때 현재 반복문 빠져나옴
					} 
					if(check1==0) {
						cnt=cnt+1;
					}//조건값이 일치할 경우 카운트에 1추가
				}
				System.out.println(cnt);
		}
		
	}
}


