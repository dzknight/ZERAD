package javawin1;

public class bumin453 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		double num=0;
		double sum=0;
		
		for(int i=100;i<=999;i++) {
			//sum=sum+i;
			int digit3=i;
			int digit2=i;
			int digit1=i;
			//ex 453
			digit3=digit3/100;
			digit2=digit2%(digit3*100)/10;
			digit1=i%100%10;
	
			
			//System.out.println(digit3+"|"+digit2+"|"+digit1);
			System.out.println(digit3+"|"+digit2+"|"+digit1);
			sum=digit3+digit2+digit1;
			num=sum+num;
		}
		System.out.println(num);
		
	}
	}

