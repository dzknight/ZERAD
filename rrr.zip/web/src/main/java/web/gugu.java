package web;
import java.util.*;
public class gugu {
	static int correct=0;//스태틱은 전역변수로만 사용가능
	static int wrong=0;
	static int proNum=0;
	/*
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GuguTimer timer=new GuguTimer();
		timer.start();
	}
	
	public static class GuguTimer extends Thread {
		@Override
		public void run() {
			GameGugu game=new GameGugu();
			System.out.println("구구단게임");
			game.start();
		}
	}
	*/
	public static class user {}
}
