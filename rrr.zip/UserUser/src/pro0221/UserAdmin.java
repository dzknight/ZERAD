package pro0221;

import java.util.Scanner;

public class UserAdmin {
	User[] ulist=new User[5];
	
	public void mainStart() {
		Scanner in=new Scanner(System.in);
		while(true) {
			menu();
			System.out.println("선택");
			int a=in.nextInt();
			in.nextLine();
			if(a==1) {
				add();
			}
			else if(a==2) {
				list();
			}else if(a==3) {
				del();
			}
			else if(a==4) {
				mod();
			}
			else if(a==5) {
				search();
			} else {
				break;
			}
		}
		
	}
	
	public void menu() {
		System.out.println("1.추가");
		System.out.println("2.전체보기");
		System.out.println("3.삭제");
		System.out.println("4.변경");
		System.out.println("5.검색");
	}
	//추가
	public void add() {
		Scanner in=new Scanner(System.in);
		System.out.println("사용자추가");	
		System.out.println("아이디입력");	
		String id=in.nextLine();
		System.out.println("이릅입력");	
		String name=in.nextLine();
		System.out.println("주소입력");	
		String addr=in.nextLine();
		System.out.println("성인여부입력");	
		String a=in.nextLine();
		boolean adult=true;
		if(a.equals("2")) {
			adult=false;
			User user=new User(id, name, addr, adult);
			
		}
		
		User user=new User(id,name,addr,adult);
		
		for(int i=0;i<ulist.length;i++) {
			if(ulist[i]==null) {
				ulist[i]=user;//주소를 저장함
				break;
			}
		}
		
		
	}
	
	//리스트
	public void list() {
		for(int i=0;i<ulist.length;i++) {
			if(ulist[i]!=null) {//nullexception방지
				ulist[i].prt();;
			}
		}
		
	}
	//아이디를 입력받아사 아이디를 일치하는 사용자 삭제
	public void del() {
		Scanner in=new Scanner(System.in);
		System.out.println("아이디입력");	
		String id=in.nextLine();
		for(int i=0;i<ulist.length;i++) {
			if(ulist[i].id!=null) {
				if(ulist[i].id.equals(id)) {
					ulist[i]=null;
					System.out.println("삭제해씁니다");
					break;
				}
			}
		}
		in.close();
		
		
		
	}
	public void mod() {
		//아이디입력받는다 배열에 찾는다 이름수정한다
		Scanner in=new Scanner(System.in);
		System.out.println("아이디입력");
		String id=in.nextLine();
		for(int i=0;i<ulist.length;i++) {
			if(ulist[i] != null) {
				if(ulist[i].id.equals(id)){
					System.out.println("수정할이름을 입력");	
					String newName=in.nextLine();
//					ulist[i].setName(newName);
					ulist[i].menu();
				}
			}
		}
		
	}
	public void search() {
		
		Scanner in=new Scanner(System.in);
		System.out.println("아이디입력");
		String id=in.nextLine();
		for(int i=0;i<ulist.length;i++) {
			if(ulist[i]!=null) {
//				if(ulist[i].id.contains(id)) {
				if(ulist[i].id.indexOf(id)!=-1) {
					ulist[i].prt();
				}
			}
		}
		
	}
}
