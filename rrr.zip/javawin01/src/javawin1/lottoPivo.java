package javawin1;

public class lottoPivo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] lotto = {6,12,33,4,5,26}  ;
		lotto[0]=lotto[0];
		System.out.println("lotto[0]"+lotto[0]);
		lotto[2]=lotto[0]+lotto[1];
		System.out.println("lotto[1]"+lotto[1]);
		lotto[2]=lotto[0]+lotto[1];
		System.out.println("lotto[2]"+lotto[2]);
		lotto[3]=lotto[2]*2;
		System.out.println("lotto[3]"+lotto[3]);
		lotto[4]=lotto[3]*2;
		System.out.println("lotto[4]"+lotto[4]);
		lotto[5]=lotto[4]*2;
		System.out.println("lotto[5]"+lotto[5]);
	}

}
