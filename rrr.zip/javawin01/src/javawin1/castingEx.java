package javawin1;

public class castingEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a =10 ; 
		int b =50 ; 
		int C =0 ; 
		Double e = 20.0 ; 
		int f =4 ; 
		int d =a+b/f ;
		System.out.println(d);
		e=b/(double)f;
		//10+12.5
		System.out.println(e);
		//12.5
	}

}
