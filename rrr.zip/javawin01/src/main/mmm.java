package main;

import java.util.HashMap;

public class mmm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap map = new HashMap<>();
		map.put("one", 1);
		map.put("two", 2);
		map.put("three", 3);
		System.out.println(map.get("two"));
		System.out.println(" "+map.toString() );
		map.remove("two");
		System.out.println(map.get("two"));
		System.out.println(" "+map.toString());
		System.out.println(" "+map.containsValue(1));
		//맵이 하나이상의 밸루를 가지는 경우 리턴불리언
		
	}

}
