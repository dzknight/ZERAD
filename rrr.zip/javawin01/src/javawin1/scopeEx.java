package javawin1;
//클래스명 클래스 내부에는 메서드가 있다
public class scopeEx {
	int GloScope=10;
							//메서드명 매개변수 용어기억
	public static void main(String[] args) {
		int a=20;
		for(int i=0;i<5;i++) {
			System.out.println(i);
			//System.out.println(k);
			int k=0;//변수가선언되면 선언되는라인부터 실행된다
			a=a+10;
			i=i+1;

		}
		a=a+10;
		//k=20;
		//i=i+1;// 스코프범위를 벗어나서
			//System.out.println(GloScope);
			//System.out.println(localScope);
		
	}
	
	public void test(int value) {
		int localScope=10;
		System.out.println(GloScope);
	}

}
