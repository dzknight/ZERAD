package javawin1;

public class bum999 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/* 5. 범인은 100부터 999까지 숫자에 숨어 있다.
		   범인은 십의 자리에 있고. 3의 배수이다. 범인 숫자를 모두 출력하시오. */
		
		
		for(int i=102;i<=999;i=i+3) {
			//세자리수 중 3의 배수인 숫자 소트 
			
				if(i/10%10==3 || i/10%10==6 || i/10%10==9 ) {
					System.out.println(i);
					//i에 10을 나눈 값에 10을 나눈 나머지가 3의 배수인것
				}
		}
	}
}


