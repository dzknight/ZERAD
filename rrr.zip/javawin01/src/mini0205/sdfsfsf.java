package mini0205;

public class sdfsfsf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[] inid=new String[10];
		int cnt=0;
		inid[0]="h";
		inid[1]="u";
		inid[2]="m";
		inid[3]="a";
		inid[4]="n";
		inid[5]="!";
		for(int i=0;i<6;i++) {
			if(inid[i].equals("!")) {
				cnt++;
			}
		}
		System.out.println(cnt);
				
	}

}
