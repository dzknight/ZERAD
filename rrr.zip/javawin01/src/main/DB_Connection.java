package main;

import java.sql.*;

public class DB_Connection {

    public static void main(String[] args) throws ClassNotFoundException, SQLException {

        Class.forName("org.mariadb.jdbc.Driver");
        Connection connection = DriverManager.getConnection("jdbc:mariadb://localhost:3306/test","root","1111");

        if(connection != null){
            System.out.println("연결 정보 : " + connection.getMetaData().getDriverName());

            PreparedStatement preparedStatement = connection.prepareStatement("select * from country");
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()){
                System.out.println( " Id    : " +resultSet.getString(1) +
                        ", Lang  : " +resultSet.getString(2)+
                        ", Money : " + resultSet.getString(3)+
                        ", Nation : " + resultSet.getString(4) +
                        ", Population : " + resultSet.getString(5)
                );
            }
        }
    }
}
