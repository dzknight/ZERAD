package javawin1;

public class tunnel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] pang={1,0,0,0,2,3,4,4,6,2,2,2,2,5} ;
		int cnt=0;
		for(int i=0;i<pang.length-2;i++) {
			cnt=1;
				for(int j=i+1;pang[i]==pang[j];j++) {
					cnt++;
				}
				if(cnt>=3) {
					System.out.println(i=i+cnt-1);
				}
		}
	}

}
