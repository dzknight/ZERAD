package pro0221;

import java.util.Scanner;

public class User {
	String id=null; 
	String name=null; 
	String addr=null; 
	String hobby[]=new String[5]; 
	 Memo[] memo=new Memo[10]; 
	boolean adult=true;
	
	public User(String id, String name, String addr,boolean adult) {
		// TODO Auto-generated constructor stub
		this.id=id;
		this.name=name;
		this.addr=addr;
		this.adult=adult;
	}

	public void prt() {
		//다른 클래스에서 멤버변수에 접근라지 말고 prt메서드를 통해 접근해라 은닉화
		System.out.println("id: "+id);
		System.out.println("이름: "+name);
		System.out.println("이름: "+name);
		String prtName =this.name;
//		if(!adult) {
//			prtName = "미성년자";
//		}
		if(adult) {
			prtName = "";
		} else {
			System.out.println("미성년지");
		}
		for(int i=0;i<hobby.length;i++) {
			if(hobby[i]!=null) {
				System.out.println("취미: "+hobby);
			}
		}
	}

	public void menu() {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		while(true) {
			System.out.println( "1.정보수정 2.메모추가 3.취미 4.나의정보");
			int a=in.nextInt();
			in.nextLine();
			if(a==1) {
				modInfo();
			} else if(a==2) {
				addMemo();
			} else if(a==3) {
				addHobby();
			} else if(a==4) {
				prt();
			} else {
				break;
			}
		
		
		}
	}

	private void addHobby() {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		System.out.println("최대5개");
		String hobbyName = null;
		for(int i=0;i<5;i++) {
			for(int j=0;j<hobby.length;j++) {
				if(hobby[i]==null) {
					
					hobby[i]=hobbyName;
				}
			}
			
			
		}
	}

	private void addMemo() {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		
		System.out.println("제목입력");
		String title=in.nextLine();
		System.out.println("내용입력");
		String content=in.nextLine();
		Memo m=new Memo();
//		m.content=content;
//		m.title=title;//간접적인 방범ㄴ
		m.setdata(title, content);
		for(int i=0;i<memo.length;i++) {
			if(memo[i]==null) {
				memo[i]=m;//---------
				break;
			}
		}
	}

	private void modInfo() {
		// TODO Auto-generated method stub
		System.out.println("새이름입력");
		Scanner in=new Scanner(System.in);
		String name=in.nextLine();
		this.name=name;
	}
	public void setName(String newName) {
		// TODO Auto-generated method stub
		this.name=name;
	}
}
