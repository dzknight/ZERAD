package javawin1;

public class array0121_45 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*int arr[]= new int[8];
		int odd=1;
		int even=2;
		for(int i=0;i<8;i++) {
			if(i==0) {
				arr[0]=odd;
				System.out.println(arr[0]);
			}  else if(i<=3 ) {
				arr[i]=odd+2*i;
				System.out.println(arr[i]);
			} else if(i==7 ) {
				arr[i]=even;
				System.out.println(arr[i]);
			} else if(i>=4 ) {
				arr[i]=arr[i-1]-1;
				System.out.println(arr[i]);
			}
		}*/
		int[] a = {34,2,35,8,31,45};
		for(int i=0;i<5;i++) {
		
			 if(a[i]<a[i+1]) {
				a[i]=0;
				System.out.println(a[i+1]);
			}else if(a[i]>a[i+1]) {
				a[i+1]=a[i];
			}
		}
		
	}
	
}
