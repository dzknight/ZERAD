package coffee;

public class customer {
	public String name;
	
}
