package javawin1;

import java.util.Arrays;

public class nameSave {

	public static <Char> void main(String[] args) {
		// TODO Auto-generated method stub
		String nameSave[]= new String[1];
		nameSave[0]="홍길동";
		System.out.println(nameSave[0]+'님');
		
		int park []= new int [1];
		int car[] = {3,4,5,6};
		System.out.println((car[0]+car[1]+car[2]+car[3])%10);
		park[0]=(car[0]+car[1]+car[2]+car[3])%10;
		System.out.println("차 3456의 주차장자리"+park[0]);
		
		int[] lotto = {6,12,33,4,5,26};
		lotto[2]=lotto[2]+80;
		//System.out.println(lotto[2]);
		
		byte[] buffers = {97, 49, 98, 50, 99, 51}; 
		//System.out.println(buffers);
		Arrays.toString(buffers);
		System.out.println((char)(buffers[0]));
		System.out.print((char)(buffers[1]));
		System.out.print((char)(buffers[2]));
		System.out.print((char)(buffers[3]));
		System.out.print((char)(buffers[4]));
		boolean sinHo[] = {true,false};
		//char sinHo[] = {1}; 
		System.out.println(sinHo[0]==true);
		System.out.println(sinHo[1]==false);
		
	}

}
