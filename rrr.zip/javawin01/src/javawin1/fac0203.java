package javawin1;

public class fac0203 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//1부터 10까지 숫자의 각패토리얼의 합을 구하시오
		int sum=1;
		int count=10;
		for(int i=10;i<11 && i>=1;i--) {
				sum=i*sum;
				for(int j=count;j>=1;j--) {
				//	System.out.println(count+"팩토리얼은"+sum);
				}
		}
		System.out.println(count+"팩토리얼은"+sum);
	}

}
