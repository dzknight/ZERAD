package javawin1;

public class Day05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int cheol=56773;
		int sum=0;
		sum=56773/10;
		
		int sum5=sum;
		sum=56773/100;
		sum=56773/10;
		
		char a=0;
		System.out.println(a);
		//sum=cheol/1000+sum;
		//sum=cheol/1000+sum;
		System.out.println(sum);
		
		/*int digit5=5;
		int digit4=6;
		int digit3=7;
		int digit2=7;
		int digit1=3;
		*/
		//System.out.println(digit5+digit4+digit3+digit2+digit1);
		
		int[] array = {5,6,7,7,3};
		
		//System.out.println(array[0]+array[1]+array[2]+array[3]+array[4]);
		//System.out.println(array[0]+""+array[1]+""+array[2]+""+array[3]+""+array[4]);
		/*
		int result = add(5,6,7,7,3);
		System.out.println(result);
		*/
		}
	/*
	public static int add(int number1,int number2,int number3,int number4,int number5) {
		int result = number1+number2+number3+number4+number5;
		return result;
	}
*/
}
