package web;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class jsEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*ScriptEngineManager manager=new ScriptEngineManager();
		ScriptEngine engine=manager.getEngineByName("nashorn");
		String str= "var greeting = 'Hello from JavaScript!'; greeting;";
		try {
			Object result=engine.eval(str);
			System.out.println(result);
		} catch (ScriptException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		ScriptEngine engine = new ScriptEngineManager().getEngineByName("nashorn"); //  --- (1)
		try {
			engine.eval("print('Hello World');");
		} catch (ScriptException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
