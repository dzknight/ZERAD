package javawin1;
import java.util.Random;

public class random3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random r=new Random();
		//참조자료형 대입연산자 생성자 만드는 선언문 랜덤이라는 메서드 생성 ->객체
		//인스턴스화 부품을 만드는것
		int a=r.nextInt(4);//메서드를 call x y 랜덤한 상수y
		//변수a선언 초기값으로 랜덤부품변수 r을참조하여 넥스트인트 를 콜하고 
		//매개변수로 4를 전달하고 넥스트인트 메서드는 0부터4까지숫자를 
		//콜위치로 리턴 이때 리턴값은 0~3까지 인트값
		
		//변수 자료형 랜덤참조(레퍼런스)변수 사용
		//함수r은 4내에서 랜덤한 숫자를 만드는 메서드 a는 랜덤한 값을 저장하는 변수
		System.out.println(r.nextInt(2));
		//2자리내에서 랜덤한 상수 생성라는것 출력
		for(int i=0;i<4;i++) {
			System.out.println(r.nextInt(3));
		}
		
		String aa="asdsd";
		String aaa=new String("가나다");
		System.out.println(aaa.charAt(1));
		System.out.println(aa.charAt(1));
		//3내의 숫자 3개를 생성하는 값 출력
	}

}
