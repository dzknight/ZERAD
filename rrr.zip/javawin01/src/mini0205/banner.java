package mini0205;

public class banner {
	public static final String red      = "\033[31m" ;
	public static final String WHITE_BACK= "\033[39m";
	public static final String cyan     = "\033[46m" ;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String randomColor="red";
		String randomBack="WHITE_BACK";
		System.out.println(red+"#@@@@███@@@@@▄██@@@█▄@@@@@▄███████▄@@@███████████@@@@@@@@@@@@@#");
		System.out.println("#  ▀█████████▄@███@@@██▄@@@███@@@@███@@@███@@@@@▀██@@@@@@@@@@@@@@  #");
		System.out.println("#  @@@@███@@@▀@▀▀▀▀▀▀███@@@███@@@@███@@@███▄▄▄@@@@@@@@@@@@@@@@@@@ #");
		System.out.println("#  @@@@███@@@@@▄██@@@███@@@████████▀@@@@███▀▀▀@@@@@@@@@@@@@@@@@@@ #");
		System.out.println("#  @@@@███@@@@@███@@@███@@@███@@@@@@@@@@███@@@@▄█@@@@@@@@@@@@@@@@#");
		System.out.println("#  @@@@███@@@@@▀███████▀@@@███@@@@@@@@@@███▄▄▄▄███@@@@@@@@@@@@@@@  #");
		System.out.println("#  @@@▄████████@@@@@@@@@@@@███@▄███████▄@@██▄███████▄@@@@@███@@@@@ #");
		System.out.println("#  @@███@@@@███@▀█████████▄@@@███@@@@███@@@███@@@@███@▀█████████▄@  #");
		System.out.println("#  @@███@@@@█▀@@@@@▀███▀▀██@@@███@@@@███@@@███@@@@███@@@@▀███▀▀██@ #");
		System.out.println("#  @@███@@@@@@@@@@@@███@@@▀@@@███@@@@███@@@███▄▄▄▄██▀@@@@@███@@@▀   #");
		System.out.println("#  ▀███████████@@@@@@███@@@@@@@██████████@@@████████@@@@@@@███@@@@ #");
		System.out.println("#  @@@@@@@@@███@@@@@███@@@@@@@███@@@@███@@@██████████@@@@@███@@@@  #");
		System.out.println("#  @@▄█@@@@@███@@@@@███@@@@@@@███@@@@███@@@███@@@@███@@@@@███@@@@  #");
		System.out.println("#  @▄████████▀@@@@@▄████▀@@@@@@███@@@@███@@███@@@@███@@@▄████▀@@@@ #");
		System.out.println("#  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@███@@@@@██▄@@@@@@@@@@@  #");
		System.out.println("#  @@@@apple@@@@bird@@@@@@@@@@@@@shoes@@@@@@@@keyboard@@@@@@@computer@@@@@@@@@@ #");
		System.out.println("#          airplane                                    bird 				cat	              	 pocket     				                      	   america#" );
		System.out.println("#                   	keyboard	                       				   							brilliant	    					   #" );
		System.out.println("#                   		                       				    computer  					 apple							#" );
		System.out.println("#                                       				   						    						manufacture		#" );
		System.out.println("#          apple                                    strength 				              temporary        					 			   job	   #" );
		System.out.println("#  @@@@@@@@airplane@@@@@@cat@@@@@@@@@@pocket@@@@america@@@@@@@@@@@@@@@@@@@@@@#");
		


		

	}

}
