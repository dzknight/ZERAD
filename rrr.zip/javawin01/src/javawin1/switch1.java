package javawin1;
import java.util.Scanner;

public class switch1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * 
		 * 
		 * */
		
		
		int a=78;
		int score=80;
		if(a>=90) {
			System.out.println("A");
		} else if(a>=80) {
			System.out.println("b");
		} else if(a>=70) {
			System.out.println("c");
		
		} else if(a>60) {
		System.out.println("d");
		
		}	else  {
	System.out.println("f");
	
}
	}
}
