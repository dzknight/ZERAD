package main;

import java.util.Arrays;

public class quiz {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [][]a = { {2, 4, 1, 2, 1},
				{3, 4, 2, 3, 3},
				{2, 4, 1, 2, 2},
				{4, 4, 4, 1, 2},
				{4, 2, 3, 3, 2}};
		
		/*
		int[][]second=new int[5][5];
		int[][]third=new int[5][5];
		for(int i=0;i<5;i++) {
			for(int j=0;j<5;j++) {
				third[i][j]=second[i][j];
			}
		}
		*/
		Arrays.sort(a);
		System.out.println(Arrays.toString(a));
		
	}

}
