package javawin1;

public class day0203 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String [] menu ={"a","b","c","d"};
		System.out.println(menu[0]);
		System.out.println(menu[1]);
		System.out.println(menu[2]);
		System.out.println(menu[3]);
		menu[2]="pizza";
		System.out.println(menu[0]);
		System.out.println(menu[1]);
		System.out.println(menu[2]);
		System.out.println(menu[3]);
	}

}
