package javawin1;

import java.util.Scanner;

public class char222 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		String sign="!@#$%^&*";
		int result=0;
		System.out.println("type name");
		 String name=in.next();
		
		for(int i=0;i<=name.length();i++) {
			char k=name.charAt(i);
			
		  System.out.println(k);
			
			for(int j=0;j<=sign.length();j++) {
				if(name.charAt(i)==sign.charAt(j)) {
					result=result+1;
					System.out.println(result);
				} //else {
					//System.out.println(name.charAt(i)+"||"+sign.charAt(i));
			//	}
				
				
			}
			//System.out.println(name.charAt(i)+"|"+sign.charAt(i));
		/*	if(k sign.indexOf(name) || k=='!' || k=='#' || k=='^' || k=='&' || k=='$' || k=='%') {
				result=result+1;
			}*/
		}
		
	//	System.out.println("특수문자가 포함된 글자수는"+result+"입니다");
	//	System.out.println("총글자수는"+name.length()+"입니다");
		
	}
}
