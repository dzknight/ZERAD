package javawin1;

public class bum100 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		for(int i=1;i<=100;i++) {
			if(i>=0 && sum==45) {
				sum=sum+i;
				if(sum == 45) {
					System.out.println(i);
				}
			} 
		}
	
	}

}
