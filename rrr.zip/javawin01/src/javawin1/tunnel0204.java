package javawin1;

public class tunnel0204 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {1,0,0,0,1,1,1,0,0,0,0,1,1,1,1,0,0,0,1};
		int size=2;//건물 사이즈
		int totalCnt=0;//전체 건물 갯수
		int cnt=0;//카운트
		
		for(int i=0;i<arr.length;i++) {//배열 길이만큼 반복
				cnt=0;//왜 이중포문을 쓰는가
				for(int j=i;j<arr.length;j++) {//j=i//for문의미 파악
						if(arr[j]==0) {//arr[j]
							cnt++;// 배열자리수가 0이라면 카운트1추가
						} else {
							break;//아니라면 브레이크하고 다음 구문으로 이동
						}
				}
				
				if(cnt>=3) {//카운드가 3이상이라면 건물 갯수 합산 카운트 시잓
					System.out.println(i+"위치의0은 오른쪽에서"+cnt+"개 연속입니다");
					totalCnt+=(cnt-size+1);
					i=i+3-1;
				}
		}
		System.out.println(totalCnt);
		
	}
}
