package program1;

import java.util.Scanner;

public class Main extends Manager{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		System.out.println("1.매니저용기능");
		System.out.println("2.이벤트이용자용기능");

		while(true) {
			String select=sc.nextLine();
			switch(select) {
			case "1":
				Manager.main(args);
				break;
			case "2":
				Event.main(args);
				break;
			}
			
		}
		
		
		
	}




}
