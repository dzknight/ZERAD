package javawin1;

public class large40 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a ={34,55,23,56,34,45,34};
		int count=0;
		for(int i=0;i<7;i++) {
				if(a[i]>=40) {
					count=count+1;
				}
		}
		System.out.println("40보다큰수의갯수는"+count+"개");
	}

}
