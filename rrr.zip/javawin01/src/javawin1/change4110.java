package javawin1;

public class change4110 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*거스름돈 구하기   10000원짜리 0개, 1000원짜리 0 개, 100짜리 0개, 10짜리 0개,  
		 
		조건 : / or % 연산자는 각각 최대 두 번씩 사용가능
		   단, 거스름돈은 만천원이 최대 값이다. 
*/
		int money=4570;  // 가격
		int pay = 10000;  //지불금액*/

		int change= 9550;
		int temp =0;
		
		for(int i=change;i<11000;i=i/10) {
			temp=i;
			System.out.println(temp);
		}
		//System.out.println("10,000원짜리"+calc[0]+" 개 1,000원짜리"+calc[1]+" 개 100원짜리"+calc[2]+" 개 10원짜리"+calc[3]+"개");
	}

}
