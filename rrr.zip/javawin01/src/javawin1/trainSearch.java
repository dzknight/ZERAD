package javawin1;
import java.util.*;
public class trainSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//기차이름검색
		//배열에 입력된 값 중 "새마을" 3글자가 일치하는 기차번호와 이름 출력
		//select train,trainNo where train=새마을
		String train=new String ();
		String names[]=new String[6];
		/*
		for(int i=1;i<=5;i++) {
			System.out.println("3글자 기차명을 입력하세요");
			
			Scanner input=new Scanner(System.in); 
			names[i]=input.next();
			//
			if(i==5) {
				System.out.println("입력을 종료");
				break;
			}
			
		}
		
		for(int i=1;i<=5;i++) {
			System.out.println("등록한 기차 이름은"+names[i]+i+"호");
			
		}
		*/
		//기차 검색

		for(int i=1;i==1;i++) {
			String dummy="새마을";
			System.out.println("검색할 기차명을 입력하세요");
			
			Scanner input=new Scanner(System.in);
			//키보드로 입력한 값이 입력된 변수
			//String dummy_equal=input.next();
			//dummy=input.next();
			
			if(dummy.equals(input.next())) {
				System.out.println("검색한 기차는"+dummy+"호입니다");
			} else {
				System.out.println(input.next()+"호는 없습니다");
			} 
		
		}
	}

}
