package javawin1;

public class chartoA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char beforeChar='a';
		char afrerChar='^';
		boolean valid = beforeChar>afrerChar;
	
		
		if(beforeChar>afrerChar) {
			System.out.println("소문자입니다");
			beforeChar=(char) (beforeChar-32);
			System.out.println(beforeChar);
			
		} 
		else {
			System.out.println("대문자입니다");
		}
	}

}
