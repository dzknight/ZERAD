package javawin1;

public class floatEx {

	public static void main(String[] args) {
		int pointJava = 10;
		int pointOracle = 50;
		int pointMaria = 80;
		char a = 'a';
		float float1 = (float) 10.123456789;
		double double1 = 123.123456789;

		double avg = 0;
		avg = (pointJava + pointMaria + pointOracle) / (double) 3;
		// avg = (float) ((pointJava+pointMaria+pointOracle)/(float)3.0);
		System.out.println(avg);
		// 6~10 11~12번에서만 수정가능 인트형이 정수형이기 때문에 정수계산이 되어 소수점 계산이 x
		// 6~10라인의 자료형을 플로트로 변경
		// 11~12 avg에 합산값을 대입하기 전에 자료형을 float로 형변환
		System.out.println(String.valueOf(pointMaria));// int to str
		System.out.println(Integer.toString(a));// int to str
		System.out.println(float1);// int to str
		System.out.println(double1);// int to str

	}

}
