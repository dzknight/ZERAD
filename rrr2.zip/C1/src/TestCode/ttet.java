package TestCode;

import java.util.ArrayList;
import java.util.HashMap;

public class ttet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<HashMap<String, String>> list = new ArrayList<HashMap<String, String>>();
		//어레이리스트안에 해시맵이 입력되도록 선언
		//어레이리스트 안에 해시맵을 삽입 가능
		
		HashMap<String, String> personMap=new HashMap<String, String>();
		personMap.put("이름", "김경태");
		personMap.put("나이", "28");
		personMap.put("직업","게이머");
		HashMap<String, String> personMap2=new HashMap<String, String>();
		personMap2.put("이름", "이아영");
		personMap2.put("나이", "28");
		personMap2.put("직업","디자이너");
		//만든 두개의 해시맵개체를 먼저 만든 어레이리스트에 넣음
		list.add(personMap);
		list.add(personMap2);
		//어레이리스트 안에 두개의 해쉬맵ㅇ 들어가게된다
		
		HashMap<String,String> takeMap1=(HashMap<String, String>)list.get(0);
		String name1=takeMap1.get("이름");
		String age1=takeMap1.get("나이");
		String job1=takeMap1.get("직업");
		System.out.println(name1+age1+job1);
		HashMap<String, String> takeMap2=(HashMap<String, String>)list.get(1);
		String name2=takeMap2.get("이름");
		String age2=takeMap2.get("나이");
		String job2=takeMap2.get("직업");
		System.out.println(name2+age2+job2);
		
	}

}
