package javawin1;

public class Day2_02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int point=0;
		double haveMoney=0.0;
		boolean havingMoney=false;
	//	char saveWord='a';
	
		//System.out.println(point);
		System.out.println(haveMoney);
		System.out.println(havingMoney);
	//	System.out.println(saveWord);
		
		int point=78;
		//boolean a = point>=60;
//		System.out.println(a);
		System.out.println(point>=60);
		double e =10/60;
		System.out.println(e);
		int a =10 ; 
		int b =50 ; 
		int f =4 ; 
		int d =a+b/f ;
		System.out.println(d);
		
	}

}
