package main;


import java.util.Arrays;


public class fsfsf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [][]arr = { 
				{2, 4, 1, 2, 1},
				{3, 4, 2, 3, 3},
				{2, 4, 1, 2, 2},
				{4, 4, 4, 1, 2},
				{4, 2, 3, 3, 2}
				};
		int target=4;
		//System.out.println(Arrays.deepToString(arr));
		//문자열로 저장
		//가로로 같은 숫자 찾기
		int total=0;
		int cnt=0;
		for(int i=0;i<arr.length;i++) {
			int temp=4;
			for(int j=0;j<arr.length;j++) {
				//System.out.print(arr[i][j]);
				
				if(arr[i][j]==temp) {
					System.out.println("if"+arr[i][j]);
					cnt++;
				} else {
					cnt=1;
					temp=arr[i][j];
				}
				if(cnt>=3) {
					System.out.println("cnt"+cnt);
				}
				
			}
			
		}
		//System.out.print(cnt);
		
		
	}

}
