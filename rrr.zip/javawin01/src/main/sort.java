package main;

import java.util.*;

public class sort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] arr = {{1,22, 12,55, 44, 4691},{1,22, 12,55, 44, 4691}};
		
		Arrays.sort(arr,new Comparator<int []>() {

			@Override
			public int compare(int[] o1, int[] o2) {
				// TODO Auto-generated method stub
				/*배열의 0번째 위치를 비교해 주고 해당 배열의 위치가 같으면, 
				 return o1[1] - o2[1]; 를통해 오름차순 정렬을 해준다. */
				
				if(o1==o2) {
					return o1[1]-o2[1];
				} else {
					return o1[0]-o2[0];
				}
				
			}}
		);
		for(int i=0;i<2;i++) {
			for(int j=0;j<6;j++) {
				System.out.println( arr[i][j] );
			}
			
		}
		
		
	}
}
