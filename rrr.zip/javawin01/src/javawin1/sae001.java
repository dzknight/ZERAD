package javawin1;

import java.util.Scanner;
import java.util.*;

public class sae001 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String 자료형에서 참조하여 사용 가능한 메서드 : charAt(), equals()
		//String train= new String();
		String names []=new String[6];
		//Scanner input=new Scanner(System.in);
		for(int i=1;i==1;i++) {
			System.out.println("세글자 기차명을 입력하세요");
			Scanner input=new Scanner(System.in);
			names[i]=input.next();//입력한 기차명이 저장될 변수 str
			System.out.println("기차의 길이는"+names[i].length());
			//System.out.println("입력한 기차명은:"+names[i]);
			
			if(names[i].length()>3) {
				System.out.println("기차길이는 3글자까지 입력하세요");
				break;
			}
			
			if(i==5) {
				System.out.println("입력을 종료");
				break;
			}
		}
		for(int i=1;i==1;i++) {
			System.out.println("등록한 기차 이름은"+names[i]+i+"호");
			
		}
		//System.out.println("기차명을 입력하세요");
		//Scanner input=new Scanner(System.in);
		//String str=input.next();//입력한 기차명이 저장될 변수 str
		//System.out.println("입력한 기차명은:"+str);
				//객체 스캐너를 생성하고 입력된 텍스트는 input에 저장
		//기차 이름과 인덱스1 밸류 번호는 인덱스1부터 시작 
		//텍스트를 입력하면 새마을 01 02 03 04 05 
		
		//시나리오 
	}

}
