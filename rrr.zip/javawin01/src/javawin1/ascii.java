package javawin1;

public class ascii {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = new int[50];
		char[] arr = {97,133,120,100,101,87,65,99,102};
		for(int i=0;i<9;i++) {
			if(arr[i]<122 && arr[i] > 96) {
				a[i]=arr[i];
			}
		}
		for(int i=0;i<9;i++) {
			if(arr[i]<122 && arr[i] > 96) {
				System.out.println(arr[i]);
			}
		}	
	}
}
