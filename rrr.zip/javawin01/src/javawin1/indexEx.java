package javawin1;

public class indexEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int []a= {3,7,4,13,8};
		int max=0;
		
	
		for(int i=0;i<5;i++) {
			if(a[max]>=a[i]) {
			
			//if(max>=a[i]) {
				a[max]=a[i];//a[3]이 가장 높은 인덱스
				max=i;
				System.out.println("a[max]인덱스"+a[max]);//인덱스로 판단
				System.out.println("a[i]인덱스"+max);//인덱스로 판단
				//높은 밸류로 판단
			}
		}
	}

}
