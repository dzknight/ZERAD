package main;

import java.util.ArrayList;

public class arrayListEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(3);//값 추가 0번 인덳스에 기본적으로 들어감
		list.add(null);//널값도 추가 가능
		list.add(1,10);//특정 위치에 값 삽입 가능 인덱스1에 10 입력
		System.out.println(list);
		/*
		ArrayList<Student> members=new ArrayList<Student>();
		Student student=new Student(name,age);//객체 생성
		members.add(student);
		members.add(new Student("aaa",15));
		*/
	}

}
