package study;

import java.util.ArrayList;
import study.*;
public class NoteM {
	
	String name=null;
	String contents=null;
	String regdate=null;
	
	ArrayList<NoteOne> noteone=new ArrayList<NoteOne>();//타입설정 노트객체만사용가능
	NoteM note=new NoteM();
	public ArrayList<NoteOne> getNoteone() {
		return noteone;
	}
	
		

		
	
}
