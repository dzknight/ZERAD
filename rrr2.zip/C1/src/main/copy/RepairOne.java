package main.copy;

public class RepairOne {
	private String repairDate=null;
	private String title=null;
	private String memo=null;
	public String getRepairDate() {
		return repairDate;
	}
	public void setRepairDate(String repairDate) {
		this.repairDate = repairDate;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	
	public void prt() {
		System.out.println("title: "+this.title);
		System.out.println("memo: "+this.memo);
		System.out.println("repairdater: "+this.repairDate);
	}
}
