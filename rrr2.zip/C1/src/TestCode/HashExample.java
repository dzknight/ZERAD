package TestCode;

import java.security.*;
public class HashExample {

	   // SHA-256 해시를 생성하는 메서드
    public static String generateHash(String input) {
        try {
            // MessageDigest 인스턴스 생성 (SHA-256 알고리즘 사용)
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            
            // 입력 문자열을 바이트 배열로 변환 후 해시 계산
            byte[] hashBytes = md.digest(input.getBytes());
            
            // 바이트 배열을 16진수 문자열로 변환
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                hexString.append(String.format("%02x", b));
            }
            
            return hexString.toString(); // 최종 해시 값 반환
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("해시 알고리즘을 찾을 수 없습니다.", e);
        }
    }

    public static void main(String[] args) {
        String input = "Hello, World!";
        String hashValue = generateHash(input);
        
        System.out.println("입력값: " + input);
        System.out.println("SHA-256 해시값: " + hashValue);
    }
}