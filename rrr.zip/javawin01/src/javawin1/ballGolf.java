package javawin1;

public class ballGolf {
	public static void main(String[] args) {
	int x=100;
	int y=50;
	int x_len=30;
	int y_len=40;

	int ballx=30;
	int bally=30;
	int ball_len=5;
	
	
	 int inOnex = x+x_len ;
	 int inOney = y+y_len ;
	 boolean inOnexy =  ballx >x & (ballx+ball_len)<x+x_len  
			 & bally >y 
			 & (bally+ball_len)<(y+y_len);
			
	 System.out.println(inOnexy);
			 
	}
	
}
