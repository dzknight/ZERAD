package main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.StringTokenizer;

public class buffer {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		System.out.println("생성할 n차 배열의 n값을 입력하세요  ");
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		//Scanner sc=new Scanner(System.in);
		//입력한 숫자만큼 n차 배열생성구문
		int n=Integer.parseInt(br.readLine());
		int[][] arr=new int[n][n];
		System.out.println(arr.length);
		//해당배열 출력함수
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr.length;j++) {
				System.out.print(arr[i][j]);
			}
			System.out.println();
		}
		int nx=1;
		int ny=1;
		System.out.println("현재좌표 ("+nx+","+ny+")");
		int [] UP= {-1,0};
		int [] DOWN= {1,0};
		int [] RIGHT= {0,1};
		int [] LEFT= {0,-1};
		int []dx= {-1,0, 0,1};//북동서남
		int []dy= { 0,1,-1,0};//북동서남
		String []move= {"U","R","L","D"};//상좌우하
		//				 ^   <    >  ∨ 
		//문자열 분리 토큰 스트링 토크나이저 객체 생성
		//토큰 방향 입력
		System.out.println("Typr U R L D");
		StringTokenizer st=new StringTokenizer(br.readLine());
		while(st.hasMoreTokens()) {//불린
			//토큰이 있는경우
			String temp=st.nextToken();//변수 템프는 스트링토크나이저의 다음토큰
			for(int i=0;i<4;i++) {//4번 반복
				int nxTemp=nx+dx[i];//N차배열의
				int nyTemp=ny+dy[i];
				//x,y 좌표값 저장변수
				
				//상하좌우와 템프변수가 같으면 
				if(temp.equals(move[i])) {
					if(nxTemp>=1 && nxTemp<n && nyTemp>=1 && nyTemp<n) {
						nx=nxTemp;
						ny=nyTemp;
					}
				}
				
			}
		}
		
		
		System.out.println("이전좌표 ("+nx+","+ny+")");
	}

}
