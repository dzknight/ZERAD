package javawin1;

public class p453 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=453;
		int sum=0;
		for(int i=100;i<=999;i++) {
			sum=sum+i;
			if(i==453) {
				int temp=i/100;
				int temp2=(i-403)/10;
				int temp1=i-450;
				System.out.println(temp+temp2+temp1);
			}
		}
		System.out.println(sum);
	}

}
