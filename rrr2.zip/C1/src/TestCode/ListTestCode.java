package TestCode;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ListTestCode {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> a=new ArrayList<String>();
				//밸류타입  변수=
		//추가하는방번
		String name="kim";
		String n="lee";
		String na="na";
		a.add(name);
		a.add(n);
		a.add(na);
		//순서있고 전체출력
//		for(int i=0;i<a.size();i++) {
//			System.out.println(i+"index:"+a.get(i));
//		}
		//순서있고 전체출력
//		for(String s:a) {
//			System.out.println("value: "+a);
//		}
		//del
		a.remove(1);//1no index 
		System.out.println(a.size());
		a.add(0, "park");//0번인덱스에 삽입하겠다
		a.set(1, "kkk");
		Collections.sort(a);
		a.forEach(s->System.out.println(s));
		
	}

}
