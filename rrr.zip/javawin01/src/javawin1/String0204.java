
package javawin1;

import java.util.*;
public class String0204 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=10;
		
		if(a==b) {
			System.out.println("same");
		}
		String aa=new String("kim");//object
		String bb=new String("kim");
		System.out.println(aa.length()+"<");
		System.out.println(aa.indexOf("im")+"<<");
		
		if(aa==bb) {
			System.out.println("same2");
		}//container
		if(aa.equals(bb)) {
			System.out.println("same3");
		}//contents
		
	}

}
