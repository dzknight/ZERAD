package javawin1;


import java.util.Arrays;

public class forSumEx {
	public static void main(String[] args) {
	/*int a[] = {1,2,3,4,5};
		for(int i=0;i!=a.length;i++) {
			System.out.println(Arrays.toString(a));
		};
		String b[]= {"sss","sss","sss","sss"}; */
		int sum= 0;
		/*for(int i=0;i<=10;i++) {
			sum=sum+i;
			
		System.out.println("dddd"+sum);
	}*/
		/*int index=1;
		while(index<=10) {
			sum=sum+index;
			index++;
	}*/
		//System.out.println(sum>>0);
		/*
		for(int i=0;i<100;i=i+2) {
			sum=i+sum;
			System.out.println("");
		}
		System.out.println("100홀수"+sum);
		*/
		for(int i=0;i<100;i++) {
			if(i%2!=0) { //i%2==1
				sum=i+sum;
			}
		}
		System.out.println("1~10sum"+sum);
		int kk=0;
		for(int i=1;i<=10;i++) {
			kk=i+kk;
		}
		System.out.println("1~10sum"+kk);
}
}
