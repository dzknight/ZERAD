package main;
import java.util.Random;
import java.util.Scanner;
public class Ex {
	static int[] lottoNum = new int[6];
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		menu();
		System.out.println("메뉴를 선택하세요");
		int num = in.nextInt();
		if(num==2) {
			randomInt();
			prtLotto();
		}else {
			manualInt();
		}		
	}
	public static void manualInt() {
		Scanner in = new Scanner(System.in);
		for(int i=0; i < lottoNum.length; i++) {
			System.out.println("1부터 45번호 중 하나를 입력하세요");
			int num = in.nextInt();
			if(num <= 0 || num >= 46) {
				System.out.println("입력 값이 잘못 됨");
				i--;
			}else {
				int flag = checkDuplex(num);
				if(flag != -100){
					System.out.println("중복. 다시입력");
					i--;
				}else {
					lottoNum[i]=num;
					prtLotto();
				}
			}
		}
	}
	public static void menu() {
		System.out.println("1. 수동");
		System.out.println("2. 자동");
	}
	public static void randomInt() {
		Random r = new Random();
		for(int i=0; i < lottoNum.length; i++) {
			int k = r.nextInt(45)+1;
			int flag = checkDuplex(k);
			if(flag != -100){
				i--;
			}else {
				lottoNum[i]=k;
			}
		}
	}
	public static int checkDuplex(int a) {
		for(int i=0; i<lottoNum.length; i++) {
			if(lottoNum[i]==a) {
				return i;
			}
		}
		return -100;
		
	}
	public static void prtLotto() {
		for(int i=0; i < lottoNum.length; i++) {
			System.out.print(lottoNum[i]+ " ");
		}
		System.out.println();
	}
}
