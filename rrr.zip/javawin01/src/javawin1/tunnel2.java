package javawin1;

public class tunnel2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int[] arr = {1,2,3,0,0,0,1,2,3,4,5,2,2,2,2,0,0,0,0,0,3,3};
		 int cnt=0;
		 int length=0;
		 for(int i=0;i<21;i++) {
			 if(arr[i]==0 && arr[i+1]!=0) {
				 length=length+1;
			 } 
			cnt=cnt+1;
		 }
		 System.out.println(arr[cnt]+"가장긴숫자&"+ cnt+"번째");
		 
	}

}
