package javawin1;

public class start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
			for(int i=4;i>=1;i--) {
				for(int j=1;j<=i;j++) {
					System.out.print("");
				}
				for(int k=1;k<=4;k++) {
					System.out.print("*");
				}
				System.out.println();
				}
				
			//	row=row+1;
			}
				
			
			
			
			
			
	}
			
		
	


