package main.copy;

import java.util.Scanner;

public class CarOne {
 //자동차 한대의 책임
	private String num=null;
	private String userName=null;
	//수리내역을 저장할 책임 수리내역은 여러개이므로 배열로선언
	private RepairOne[] repairList =new RepairOne[5];
	
	public void prt() {
		System.out.println("owner: "+this.num);
		System.out.println("name: "+this.userName);
		System.out.println("정비내역: ");
		listRepair();
//		for(RepairOne r:repairList) {
//			if(repairList!=null) {
//				r.prt();
//			}
//		}
	}
	
	public String getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num = num;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public RepairOne[] getRepairList() {
		return repairList;
	}

	public void setRepairList(RepairOne[] repairList) {
		this.repairList = repairList;
	}

	public void menu() {
		Scanner in= new Scanner(System.in);
		boolean flag=true;//들어갈 라인 순서
		while(flag) {
			System.out.println("1.수리등록 2.전체보기");
			System.out.println("번호선택");
			int a=in.nextInt();
			in.nextLine();
			switch (a) {
			case 1:
				addRepair();
				break;
			case 2:
				listRepair();
				break;
			default:
				flag=false;
				
			}
			
		}
	}


	private void listRepair() {
		// TODO Auto-generated method stub
		for(RepairOne r:repairList) {
			if(r!=null) {
				r.prt();
			}
		}
	}


	private void addRepair() {
		// TODO Auto-generated method stub
		//정보입력 객체생성 배열에 주소 복사
		Scanner in= new Scanner(System.in);
//		in.nextLine();
		String title=in.nextLine();
		String memo=in.nextLine();
		String date=in.nextLine();
		RepairOne re=new RepairOne();
		
		re.setTitle(title);//오류내역코드부분
		re.setMemo(memo);//
		re.setRepairDate(date);//
		for(int i=0;i<repairList.length;i++) {
			if(repairList[i]==null) {
				repairList[i]=re;
				break;
			}
		}
	}
}
