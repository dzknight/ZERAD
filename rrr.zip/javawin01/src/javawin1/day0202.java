package javawin1;

import java.util.Random;

public class day0202 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
		
		//저장값을 각각의 번호에 맞는 인덱스에 저장하고 반복하는 기능을 위한 for문
		//1000번 실행
	/*	for(int i=0;i<100;i++) {
			int a=r.nextInt(45)+1;
			//45내에서 난수생성 메서드에서 리턴한 값 a에 저장 전역변수
			//lotto[0]=a;
			//a값을 배열 1번째에 저장
			//System.out.println(lotto[0]);
			//저장한 난수 값 확인
			if(r.nextInt(45)==1) {
				lotto[0]=lotto[0]+1;
			} else if(r.nextInt(45)==2) {
				lotto[1]=lotto[1]+1;
			} else if(r.nextInt(45)==3) {
				lotto[2]=lotto[2]+1;
			} else if(r.nextInt(45)==4) {
				lotto[3]=lotto[3]+1;
			} else if(r.nextInt(45)==5) {
				lotto[4]=lotto[4]+1;
			} else if(r.nextInt(45)==6) {
				lotto[5]=lotto[5]+1;
			} else if(r.nextInt(45)==7) {
				lotto[6]=lotto[6]+1;
			} else if(r.nextInt(45)==8) {
				lotto[7]=lotto[7]+1;
			} else if(r.nextInt(45)==9) {
				lotto[8]=lotto[8]+1;
			} else if(r.nextInt(45)==10) {
				lotto[9]=lotto[9]+1;
			} else if(r.nextInt(45)==11) {
				lotto[10]=lotto[10]+1;
			} else if(r.nextInt(45)==12) {
				lotto[11]=lotto[11]+1;
			} else if(r.nextInt(45)==13) {
				lotto[12]=lotto[12]+1;
			}
			else if(r.nextInt(45)==14) {
				lotto[13]=lotto[13]+1;
			}
			else if(r.nextInt(45)==15) {
				lotto[14]=lotto[14]+1;
			}
			else if(r.nextInt(45)==16) {
				lotto[15]=lotto[14]+1;
			}
			else if(r.nextInt(45)==17) {
				lotto[16]=lotto[16]+1;
			}
			else if(r.nextInt(45)==18) {
				lotto[17]=lotto[17]+1;
			}
			else if(r.nextInt(45)==19) {
				lotto[17]=lotto[17]+1;
			}
			else if(r.nextInt(45)==20) {
				lotto[17]=lotto[17]+1;
			}
			else if(r.nextInt(45)==21) {
				lotto[17]=lotto[17]+1;
			}
			else if(r.nextInt(45)==22) {
				lotto[17]=lotto[17]+1;
			}
			else if(r.nextInt(45)==23) {
				lotto[17]=lotto[17]+1;
			}
			else if(r.nextInt(45)==24) {
				lotto[17]=lotto[17]+1;
			}
			else if(r.nextInt(45)==25) {
				lotto[17]=lotto[17]+1;
			}
			else if(r.nextInt(45)==26) {
				lotto[17]=lotto[17]+1;
			}
			else if(r.nextInt(45)==27) {
				lotto[17]=lotto[17]+1;
			}
			else if(r.nextInt(45)==28) {
				lotto[17]=lotto[17]+1;
			}
			else if(r.nextInt(45)==29) {
				lotto[17]=lotto[17]+1;
			}
			else if(r.nextInt(45)==30) {
				lotto[17]=lotto[17]+1;
			}
			else if(r.nextInt(45)==31) {
				lotto[17]=lotto[17]+1;
			}
			else if(r.nextInt(45)==32) {
				lotto[17]=lotto[17]+1;
			}
			else if(r.nextInt(45)==33) {
				lotto[17]=lotto[17]+1;
			}
			else if(r.nextInt(45)==34) {
				lotto[17]=lotto[17]+1;
			}
			else if(r.nextInt(45)==35) {
				lotto[17]=lotto[17]+1;
			}
			
		}*/
		Random lotto=new Random();
		//난수 생성 변수 r 생성
		int count[]= new int[45];
		//로또번호 저장  변수 lotto 길이45로 생성 전역변수
		//1~45 배열에 각각 숫자별 생성 갯수 카운팅
		
		for(int i=0;i<1001;i++) {
			//1000번 반복
			count[lotto.nextInt(45)]++;
			//lotto.nextInt(45)메서드로 생성한 배열에 난수 1~45값 1000번 추가
			//
			System.out.println(count[lotto.nextInt(45)]);
			
		}
		for(int i=0;i<45;i++) {
			System.out.println((i+1)+"|"+count[i]);
			  /*(i+1) 배열0번1000100+1 +"|"+count[i]->배열에 누적저장한 값 출력;*/
		}
		/*
		System.out.println("1의 횟수는"+lotto[0]);
		System.out.println("2의 횟수는"+lotto[1]);
		System.out.println("3의 횟수는"+lotto[2]);
		System.out.println("4의 횟수는"+lotto[3]);
		System.out.println("5의 횟수는"+lotto[4]);
		System.out.println("6의 횟수는"+lotto[5]);
		System.out.println("7의 횟수는"+lotto[6]);
		System.out.println("8의 횟수는"+lotto[7]);
		System.out.println("9의 횟수는"+lotto[8]);
		System.out.println("10의 횟수는"+lotto[9]);
		System.out.println("11의 횟수는"+lotto[10]);
		System.out.println("12의 횟수는"+lotto[11]);
		System.out.println("13의 횟수는"+lotto[12]);
		System.out.println("14의 횟수는"+lotto[13]);
		System.out.println("15의 횟수는"+lotto[14]);
		System.out.println("16의 횟수는"+lotto[15]);
		System.out.println("17의 횟수는"+lotto[16]);
		System.out.println("18의 횟수는"+lotto[17]);*/
	}

}
