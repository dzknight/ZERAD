package javawin1;


import java.util.Random;

public class random2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random lotto = new Random();
		int [] count = new int[45];
		for(int i=0;i<1001;i++) {
			count[lotto.nextInt(45)]++;
			//lotto.nextInt(45)메서드로 생성한 배열에 난수 1~45값 1000번 추가
		}
		for(int i=0;i<45;i++) {
			System.out.println("번호: " + (i+1)+ " "+ "개수: "+ count[i]);
		}

	}

}