package javawin1;

public class Day01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//주석
		System.out.println("hello ");
		int a=0;//선언문 초기값 0
		int b=0;
		int c=a+b;
		System.out.println(c); //c변수값을 콘솔에출력하는 명령문
		/*
		 * 주석
		 * 
		 * */
		a=30;
		b=50;
		System.out.println(a);
		c=a+b;
		System.out.println(c);
	}

}
