package javawin1;

public class anypang {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] pang={1,0,0,0,2,3,4,4,6,2,2,2,2,5} ;
		
		System.out.println("길이배열"+pang.length);
		for(int i=0;i<pang.length-2;i++) {//익셉션 방지
			System.out.print(i+" :  ");
			int cnt=1;
			for(int j=i+1;j<pang.length && pang[i]==pang[j];j++) {
				//배열길이 초과하는 값을 참조하려하면 익셉션이 발생하는데 이것을 방지하기 위해
				System.out.print(j+"  ");
				cnt++;
			/*	if(j==pang.length-1 ) {//14번 인덱스
					//break; //브레이크는 현재반복문을 종료한다 여기서 현재반복문은 11번 for
				} */
			}
			if(cnt>=3) {
				System.out.println("총길이"+cnt);
				i+=cnt;
			}
			System.out.println();
		}
	}
}
