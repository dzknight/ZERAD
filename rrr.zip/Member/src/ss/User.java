
package ss;

public class User {
	public String id;
	public String name;
	public String addr;
	public boolean ageType;
	public String[] hobby = new String[5];
	public String[] text = new String[10];
	
	public User(String id, String name, String addr, boolean ageType) {
		this.id = id;
		this.name = name;
		this.addr = addr;
		this.ageType = ageType;	
	}
}