package study;
import java.util.*;
public class DataAdder {
	public void addData() {
		SingletonHashMap singleton = SingletonHashMap.getInstance();
		Scanner in=new Scanner(System.in);
		System.out.println("id를 입력하세요");
		String id=in.nextLine();
		System.out.println("pw를 입력하세요");
		String pass=in.nextLine();
		singleton.putData("id", id);
		singleton.putData("password", pass);
		System.out.println("id는: "+id+"pass: "+pass);
		
	}
}
