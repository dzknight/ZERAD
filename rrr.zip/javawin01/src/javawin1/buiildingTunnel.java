package javawin1;

public class buiildingTunnel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {1,0,0,0,1,1,1,0,0,0,0,1,1,1,1,0,0,0,1};
		int size=2;//건물의 크기 
		int space=0;
		
		for(int i=0;i<=18;i++) {
			if(arr[i]==0 && arr[i+1]==0) {
				space=space+1;
			}
			System.out.println(space);
		}
		
		
		/* 공터는 연속적으로 있어야 한다.
		 * 현재위치가 0이고 다음값이0에 건물을 지울수 있다 
		 공터에 건물을 지을 수 있는 위치는 모두 몇개인가?
		size가 2일경우에 7개이다.*/
		
		
			
		}
	

}
