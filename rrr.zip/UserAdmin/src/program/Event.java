package program;

import java.util.HashMap;

//이벤트 등록 
		public class Event {
		
		
		String eventName=null;
		/*
		public HashMap getEventName(){
			return this.eventName;
		};
		*/
		
	
			
	}
		

