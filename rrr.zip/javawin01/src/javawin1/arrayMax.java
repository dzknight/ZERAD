package javawin1;

public class arrayMax {
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {45,23,25,64,3,24,48};
		int cnt=0;
		int sum=0;
		for(int i=0;i<8;i++) {
			if(arr[i]%2==0) {	
				cnt=cnt+1;
				System.out.println(i);
				
			}
		}
		System.out.println(cnt);
		
		
	}

}
