package main;

import javawin1.array01;

public class moveArray {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int []arr= {1,2,3,4};
		//printf(arr);
		int temp=arr[arr.length-1];//2 배열 마지막값
		for(int j=arr.length-1;j>=0;j--) {//배열마지막값부터 0까지 반복 
			if(j==0) {//배열처음이라면  
				arr[0]=temp;//배열 마지막값을 처음값으로 변경
				break;
			}
			arr[j]=arr[j-1];
		}
		for(int i=0;i < arr.length;i++) {
			System.out.print(arr[i]);
			if(arr.length-1==i) {
				System.out.println();
			}
		}
		
	}
	//배열출력 메서드
	/*
	public static void printf(int arr[]) {
		for(int i=0;i < arr.length;i++) {
			System.out.print(arr[i]);
			if(arr.length-1==i) {
				System.out.println();
			}
		}
	}
	*/

}
