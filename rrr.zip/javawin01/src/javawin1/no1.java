package javawin1;


	import java.util.Scanner;

	public class no1 {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Scanner in = new Scanner(System.in);
			String[] menu = {"만두","라조기","돈파육","짜장면","짬뽕"};
			System.out.println("메뉴를 선택하세요 종료는 999");
			System.out.println("만두:0,라조기:1,동파육:2,:짜장면:3,짬뽕:4");
			int menu_no = in.nextInt();
		
			
			for(int i=1;i<2;i++) {

				menu_no = in.nextInt();
				menu[i]=in.nextLine();
				System.out.println(menu[i]);
				if(menu_no==999) {
					//break;
				}
			}
			
		//	System.out.println(in.nextInt());
		
		
	}
	}
