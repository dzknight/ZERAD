package user;

import java.util.Scanner;

public class UserManager {
	User [] userList= new User[5];
	UserManager(String title){
		System.out.println(title+"회원관리 프로그램");
		Scanner in =new Scanner(System.in);
		while(true) {
			menu();
			System.out.println("번호선택");
			int k=in.nextInt();
			if(k==1) {
				add();
			} else {
				allList();
			}
		}
	}
	private void menu() {
		// TODO Auto-generated method stub
		System.out.println("1.추가 2.전체보기");
	}
	private void allList() {
		// TODO Auto-generated method stub
		System.out.println("전체보기기능");
		for(int i=0;i<userList.length;i++) {
			if(userList[i]!=null) {
				System.out.println(userList[i].id);
			}
		}
	}
	
	private void add() {
		// TODO Auto-generated method stub
		System.out.println("추가");
		Scanner in=new Scanner(System.in);
		System.out.println("input id");
		String id=in.nextLine();
		System.out.println("input name");
		String name=in.nextLine();
		User tempUser=new User(id,name);
		for(int i=0;i<userList.length;i++) {
			if(userList==null) {
				userList[i]=tempUser;
				break;
			}
		}
	}
}
