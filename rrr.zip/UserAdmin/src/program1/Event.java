package program1;

import java.util.HashMap;
import java.util.Scanner;

public class Event {
	static HashMap event = new HashMap<>();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		//저장 자료명
		event.put("수영", 1);
		event.put("자바", 2);
		event.put("축구", 3);
		event.put("야구", 4);

		String eventName=null;//스캐너 입력 변수
		int eventId=event.size();
		//System.out.println(eventId);//배열아이디
		
		
		//System.out.println(event.toString());
		menu();
		while(true) {
			
			String select=sc.nextLine();
			switch(select) {
			case "1":
				System.out.println("이벤트 등록");
				System.out.println("이벤트 이름을 입력하세요");
				eventName=sc.nextLine();
				if(event.containsKey(eventName)) {
					System.out.println("사용중입니다");
				} else{ 
					event.containsKey(eventName);
					event.put(eventName, eventId+1);
					System.out.println(eventName+"등록되었습니다");
					//System.out.println(event.entrySet());
				}
				break;
			case "2":
				System.out.println("이벤트 전체보기");
				System.out.println(event.toString());
				break;
			case "3":
				System.out.println("관리자용 기능입니다");
				break;
			case "4":
				System.out.println("관리자용 기능입니다");
				break;

			case "5":
				System.out.println("이벤트 검색");
				System.out.println("검색할 이벤트 이름을 입력하세요");
				eventName=sc.nextLine();
				if(!event.containsKey(eventName)) {
					System.out.println("검색결과는 존재하지않습니다");
				} else if(event.containsKey(eventName)) {
					System.out.println("검색결과는"+eventName);
				}
			}
			break; 
			
		}
	}
	
	public static void menu() {
		//Scanner sc =new Scanner(System.in);
		System.out.println("1.이벤트 등록");
		System.out.println("2.이벤트 전체보기");
		//System.out.println("3.이벤트 삭제");
		//System.out.println("4.이벤트 수정");
		System.out.println("5.이벤트 검색");
		//String select=sc.nextLine();
	}

}
