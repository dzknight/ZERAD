package user;

import java.util.Scanner;

public class Main {
	//메인메서드는 스태틱이 있어서 객체생성자 없어도 호출가능
	//프로그램이 실행ㄷ괴면 jvm이 제일먼저 메인메서드를 호출한다
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("프로그램을 실행");
		//객체생성 생성자(인자) 생성자를 콜하여 ㄱ객체를 만든다
		new UserManager("human");

	}	
	
}
