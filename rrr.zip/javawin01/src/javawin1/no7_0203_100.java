package javawin1;

public class no7_0203_100 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<101;i++) {
			if(i%3==0 || i%2==0) {
				continue;
			}
			System.out.println("i"+i);
		}
	}

}
