package study;

public class DataRetriever {
    public void retrieveData() {
        SingletonHashMap singleton = SingletonHashMap.getInstance();
        String id = singleton.getData("id");
        String pass = singleton.getData("pass");

        System.out.println("아이디: " + id);
        System.out.println("비밀번호: " + pass);
    }
}
