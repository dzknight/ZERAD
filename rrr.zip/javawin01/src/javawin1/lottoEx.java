package javawin1;

public class lottoEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=70;
		int b=59;
	
		
		int[] lotto = {6,12,33,4,5,26};
		if((lotto[0]%2)!=0) {
			System.out.println(lotto[0]);
		} else {
			//System.out.println("0");
			lotto[0]=0;
		}
		if((lotto[1]%2)!=0) {
			//System.out.println(lotto[1]);
		} else {
			lotto[1]=0;
		}
		if((lotto[2]%2)!=0) {
			//System.out.println(lotto[2]);
		} else {
			lotto[2]=0;
		}
		if((lotto[3]%2)!=0) {
			//System.out.println(lotto[3]);
		} else {
			lotto[3]=0;
		}
		if((lotto[4]%2)!=0) {
			//System.out.println(lotto[4]);
		} else {
			//System.out.println("0");
			lotto[4]=0;
		}
		if((lotto[5]%2)!=0) {
			System.out.println(lotto[5]);
		} else {
			lotto[5]=0;
		}
		System.out.print(lotto[0]+lotto[1]+lotto[2]+lotto[3]+lotto[4]+lotto[5]);
		
		
			
		
			
		
		
	}

}
