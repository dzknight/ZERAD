package ss;

public class Main {

	public static void main(String[] args) {
		UserManager userM = new UserManager();
		
		System.out.println("프로그램을 시작합니다");
		userM.menu();
	}

}
