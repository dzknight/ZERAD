package javawin1;
import java.util.Scanner;

public class no2222 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in= new Scanner(System.in);
		String[] menu ={"만두","라조기", "동파육","짜장면","짬뽕"} ;
		String[] menuCart ={"만두","라조기", "동파육","짜장면","짬뽕"} ;
		System.out.println("메뉴를 입력하세요 만두는1 라조기는2 동파육은3 짜장면4번 짬뽕5번 (종료는999)" );
		int temp =in.nextInt();
		//menu[i] =in.nextLine()+1;
		//System.out.println(temp);	
		//System.out.println(-"주문메뉴는"+menu[1]+" 메뉴번호는"+temp);	
	/*	if(in.nextInt()<6 ) {
			//System.out.println("지금까지주문한메뉴는"+menu[1]);
			//System.out.println("메뉴가 없습니다");
		} */
		for(int i=temp;i==temp;i++) {
			System.out.println("주문메뉴는"+menu[i-1]);	
			
			if(i==999)
			{
				System.out.println("감사합니다");
				break;
			}
		}
		/*
		for(int i=1;i<5;i++) {
			//String menuCart[]= {};
			//menuCart[i]	=menu[i-1];
		*/	
			

		
			

			
		}
				
		}
		



