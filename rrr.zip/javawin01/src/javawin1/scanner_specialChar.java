package javawin1;
import java.util.Scanner;

public class scanner_specialChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);//스캐너 메서드  in생성
		String sign="!@#$%^&*";//비교할 문자열들을 담을 스트링타입 객체
		int cnt=0;//특수문자를 담을 정수형 변수
		System.out.println("아이디입력");
		String id=in.nextLine();//키보드로 입력한 값을 저장할 스트링타입 변수 id
		for(int i=0;i<id.length();i++) {//초기갑이 0인 이유는 문자열의 처음부터 비교하기 위해 
			for(int j=0;j<sign.length();j++) {//입력한 문자열과 특수문자 문자열을 비교하기 위해 특수문자배열과 키보드로 입력한 문자열을 서로 비교하는 반복문
				if(id.charAt(i)==sign.charAt(j)) {//각각의 문자열에 대응되는 자리수의 문자들을 비교
					cnt++;//같은 문자가 있다면 카운트를 1씩 가산
				}
			}
			
		}
		
		if(cnt<1) {
			System.out.println("특수문자가 없음");
		}
		System.out.println("특수문자가 포함"+cnt+"입니다");//특수문자가 몇개 포함되어있는지 카운트 변수 출력
	}

}
