package mini0205;

public class no4_0211 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[][]= {
						{1,1,0,2},
						{3,2,1,2},
						{0,0,3,2},
						{4,4,4,4},
						{2,4,3,1},
						{2,4,1,3}
					};
		int arr1[][]= {
				{16,17,18,19,20},
				{15,14,13,12,11},
				{6,7,8,9,10},
				{5,4,3,2,1}
			};
		int cnt=0;
		int temp=0;
		for(int i=0;i<6;i++) {
			for(int j=0;j<4;j++) {
				
			    if(4==arr[i][j]) {
			    	if(temp==arr[i][j] ) {
						temp=arr[i][j];
						cnt++;
			    	}
			    	temp=arr[i][j];
			    	System.out.println("("+i+","+j+")");
			    }
			}
			System.out.println();
		}
		
	}
}
