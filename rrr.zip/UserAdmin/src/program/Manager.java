package program;



public class Manager {
	Event  userList[]= new Event[5];
	String id=null;
	String name=null;
	String event=null;
	Manager(String id,String name,String event){
		this.id=id;//자기자신의 멤버변수
		this.name=name;
		this.event=event;
		
	}
}
