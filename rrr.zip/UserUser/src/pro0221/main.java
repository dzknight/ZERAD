package pro0221;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//의존한다는 걳은 객체가 필요ㅗ하다는 것
		//1객체를 만든다 2객체의 주소ㅓ값을 갖는다
		UserAdmin useradmin=null;//객체를 알아야한다
		//객체를 알아야한다
		useradmin =new UserAdmin();
		//객체를 직접 생성해서 알게됨
		useradmin.mainStart();
	}

}
