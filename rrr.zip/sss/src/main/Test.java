package main;

import java.util.ArrayList;
import java.util.Arrays;

public class Test {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> color = new ArrayList<>(); // 타입 지정
		color.add("white");
		color.add(0,"green");
		color.add(0, "blue");
		System.out.println(color);
	}

}
