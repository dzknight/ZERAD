package javawin1;

public class no010203 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0;i<4;i++) {
			for(int j=0;j<7-(i*2) ;j++) {
				System.out.print("*");
			}
			System.out.println(" ");
		}
	}

}
