package javawin1;

public class upper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		char beforeChar='a';
		char afrerChar='^';
		boolean test = beforeChar>=afrerChar;
		System.out.println(test);
		
		
	}

}
