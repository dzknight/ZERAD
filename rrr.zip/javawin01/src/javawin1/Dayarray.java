package javawin1;

public class Dayarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double dart[]={50,85,90,0,77};
		System.out.println(dart[0]+dart[1]+dart[2]+dart[3]+dart[4]/5);
		
		int point[] ={80};
		System.out.println(point[0]);
		
		double twoSave[] = new double [2];
		twoSave[0]=10.0;
		twoSave[1]=4.0;
		System.out.println(twoSave[0]%twoSave[1]);
		
		String nameSave[] = {};
		nameSave[0]="홍길동";
		System.out.println(nameSave);
		}
		
	}


