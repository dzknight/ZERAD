package javawin1;

public class letter111 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] letter={8,12,3,13,1,14,3,4};
		/* letter  배열은 word문자열 알파벳의 위치이다. 
		letter배열의 암호를 풀어서 편지의 내용을 출력하시오.
		알파벳 위치는 소문자 a로 부터의 거리이다. 단, 소문자 a는 거리가 1이다.*/

		for(int i=0;i<8;i++) {
			char t=(char) ((char)letter[i]+96);
			System.out.println(t);
		}
	}

}
