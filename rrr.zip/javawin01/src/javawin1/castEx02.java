package javawin1;

public class castEx02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=50;
		int c=0;
		double e=10;
		int f=4;
		
		c=a+b;//60
		int d=a+b/f;//22
		b=d;//22
		e=b/(double)f; // 22//4.0 ->5.5
		int g = (int)(b/(double)f);   //22/4-> 5.5->5
		
		System.out.println(a);//10
		System.out.println(b);//22
		System.out.println(c);//60
		System.out.println(d);//22
		System.out.println(e);//5.5 
		System.out.println(f);//4
		System.out.println(g);//5
	}

}
