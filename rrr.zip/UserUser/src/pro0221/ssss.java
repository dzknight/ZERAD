package pro0221;

public class ssss {
	 static String aaa=null;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		aaa="111";
	}
	void tst() {
		aaa="111";
	}

}
