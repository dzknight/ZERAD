package javawin1;

public class carnum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
								//2       1      5    2->3  4      6       7      8       9      9->0
		int[] carnum = {1232,1221,1235,1252,1234,4536,3457,3238,3229,2599};
		int[] parking = new int[10];
		//  carnum배열의 인덱스가 0인 값부터 주차장에 들어온다. --들어오는 순서
		  // carnum배열은 자동차 번호를 의미합니다. 
		//   parking의 인덱스 번호가 주차번호이다. 
		 //  자동차 번호의 마지막 번호는 해당 차량이 주차할 주차번호인덱스이다.
		//   만약 주차번호에 다른 차량이 주차되어 있으면 다음 주차번호에 주차를 한다.
		  // 주차가 끝난 후 주차번호와 주차항 차량 번호를 출력하시오.
		//3229 2599
		
			for(int i=0;i<10;i++) {
				
				for(int j=0;j<1;j++) {
					if(parking[i]==carnum[i]%10) {
						parking[i]=carnum[i];
					} else if(parking[i]!=carnum[i]%10) {
						parking[i+1]=carnum[i]%10;
						
					} else if(parking[i]!=0) {
						System.out.println("s");
					}
				}
			System.out.println(carnum[i]%10+"|"+carnum[i]);
			}
			
			
			
		}
	}


