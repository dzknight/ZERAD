package javawin1;
import java.util.*;

public class inputTrain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//새마을09
		String time[] = {"00","09","11","13","15","17"};
		//시간 저장 정수 배열 6개
		String names []=new String[6];
		//기차이름 저장배열
		for(int i=1;i<=6;i++) {
			System.out.println("세글자 기차명을 입력하세요");
			Scanner input=new Scanner(System.in);
			names[i]=input.next();
			//키보드로입력한 문자 저장할 변수
			//System.out.println("기차의 길이는"+names[i].length());
			
			if(names[i].length()>3) {
				System.out.println("기차길이는 3글자까지 입력하세요");
				break;
			}
			if(i==5) {
				System.out.println("5회 등록후 입력을 종료");
				break;
			}
			
		}
		for(int i=1;i<=6;i++) {
			System.out.println("등록한 기차 이름은"+names[i]+i+"호 시간은"+time[i]+"시");
			break;
		}
		
		for(int i=1;i<=6;i++) {
			//String dummy="새마을";
			
			System.out.println("검색할 기차명을 입력하세요");
			
			Scanner input=new Scanner(System.in);
			//키보드로 입력한 값이 입력된 변수
			//String dummy_equal=input.next();
			//dummy=input.next();
			
			if(names[i].equals(input.next())) {
				System.out.println("검색한 기차는"+names[i]+"호 시간은"+time[i]);
			} else {
				System.out.println(input.next()+"호는 없습니다");
				i--;
			}
		}
	}
	
}
		



