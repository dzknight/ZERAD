package javawin1;

public class find755 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = new int[1000];

	/*	for(int i=0; i<1000;i++){
			cnt++;
			a[i]=i+1;
			
		} */
		//System.out.println(cnt);
		int cnt=0;
		int findInt = 755; 
		for(int fcnt=0; fcnt<1000;fcnt++){
			cnt++;
			a[fcnt]=fcnt+1;
			
			if(a[fcnt]==findInt) 
			{
				System.out.println(findInt+"");
			}
			
		} 
	}

}
