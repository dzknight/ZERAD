package mini0205;

public class sasas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   int  a=3;
		   int  b=2;
System.out.println(a/b);		
	}

}
