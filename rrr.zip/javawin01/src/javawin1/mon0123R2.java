package javawin1;
import java.util.Random;

public class mon0123R2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random lotto=new Random();
		//난수 만드는 함수 생성
		float count[]=new float[45];
		//각 45자리수별 저장할 배열변수 생성
		
		float max=0;//최대값을 저장하는 변수
		float min=0;//최소값을 저장하는 변수
		float sum=0;//최소값을 저장하는 변수
		float[] avg=new float[45];
		for(int i=0;i<1001;i++) {
			count[lotto.nextInt(45)]++;
			//sum=count[lotto.nextInt(45)];
			
			if(max<count[lotto.nextInt(45)]) {
				max=count[lotto.nextInt(45)];
				
			} else if(min>count[lotto.nextInt(45)]){
				min=count[lotto.nextInt(45)];
			}
			
		}
		float max45=0;
		float min45=0;
		System.out.println(max/1000+"|"+min/1000);
		for(int i=0;i<45;i++) {
			System.out.println("번호: " + (i+1)+ " "+ "개수: "+ count[i]+" 확률 "+(float)count[i]/1000);
		System.out.println("개수: "+ count[i]+" 확률 "+(float)count[i]/1000);
			sum=(float)count[i]/1000;
			
			avg[i]=count[i]/1000;
			if(avg[i]>max45) {
				max45=avg[i];
			} else if(avg[i]<min45) {
				min45=avg[i];
			}
		}
		System.out.println("최대 |"+(float)max45+" 최소 |"+(float)min45+"평균"+sum);
		
		}
	}


