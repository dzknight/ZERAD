package javawin1;

public class parking0204 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] carnum = {1232,1221,1235,1252,1234,4536,3457,3238,3229,2599};
		int[] parking = new int[10];
		
		int nowCar=0;//현재차번호
		int nowCarPosIdx=nowCar%10;//차번호의 마지막 숫자가 차고인덱스
		int totalCarCnt=0;//모든차 카운트
		
		for(int i=0;i<carnum.length;i++) {//초기주차정보분석
			nowCar=carnum[i];//배열의 차번호 마지막 번호 가져온 것을 나우카에 임시저장
			nowCarPosIdx=nowCar%10;
			System.out.println(nowCar+"는"+nowCarPosIdx+"이 주차자리입니다");
			
			if(totalCarCnt<carnum.length) {//전체차수10보다 >모든차카운트가 작다면
				for(;parking[nowCarPosIdx]!=0;) {//반복문 주차장에 인덱스가  0일때까지
					nowCarPosIdx=(nowCarPosIdx+1)%(carnum.length);
					System.out.println("새로운 번호로 배정"+nowCarPosIdx);
				}
				//반복문에서 빈자리를 찾았다면
				System.out.println(nowCarPosIdx+"에 주차합니다");
				parking[nowCarPosIdx]=nowCar;
				totalCarCnt++;
		}
		}
		//주차자리가 이미 점유하고 있을때 3229 2599 1232 1252 다음 인덱스로 이동
		//if(nowCarPosIdx!=0) {
	}

}
