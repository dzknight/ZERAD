package javawin1;

public class index22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] lotto = {6,12,33,4,5,26};//odd
		int count=0;
		if(lotto[0]%2==0) {
			count=count+1;
		} 
		if(lotto[1]%2==0) {
			count=count+1;
		} 
		if(lotto[2]%2==0) {
			count=count+1;
		} 
		if(lotto[3]%2==0) {
			count=count+1;
		} 
		if(lotto[4]%2==0) {
			count=count+1;
		} 
		if(lotto[5]%2==0) {
			count=count+1;
		} 
		System.out.println(count);	
		
	}

}
