package web;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class valut {
	public static final int vaultPass=9999;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random rd=new Random();
		Vault vailt = new Vault(rd.nextInt(vaultPass)); 
	}
	
	private static class Vault {
		private int password;
		public Vault(int password) {
			// TODO Auto-generated constructor stub
			this.password=password;//변수이름이 비슷할 경우 구분하기 위해 붙이는생성자
		}

		
	}

	private int password;
	
	 public boolean incorrectPass(int guess){
		 try{
			 Thread.sleep(5);
		 } catch(InterruptedException e) {
			 
		 }
		 return this.password==guess;
		 
		
	};

}
