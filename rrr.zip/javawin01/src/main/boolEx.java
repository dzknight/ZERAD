package main;

import java.util.Arrays;

public class boolEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean [] boolArray=new boolean[5];
		for(int i=0;i<boolArray.length;i++) {
			System.out.println(boolArray[i]);//배열초기값 모두false
		}
		boolean[][] expected= {{true,true,true,true,true},{true,true,true,true,true}};
		boolean[] myArray=new boolean[5];
		Arrays.fill(myArray,true);
		System.out.println(myArray[1]);
	}
}
