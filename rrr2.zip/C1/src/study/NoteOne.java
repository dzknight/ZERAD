package study;

import java.util.*;

public class NoteOne {
	private String title;
	private String memo;
	private String regtime;
	String id;
	
	ArrayList<String> list=new ArrayList<String>();
	
	NoteOne noteone=new NoteOne(title,memo,regtime);
	
	public NoteOne(String title2, String memo2, String regtime2) {
		// TODO Auto-generated constructor stub
		this.title=title;
		this.memo=memo;
		this.regtime=regtime;
		
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public String getRegtime() {
		return regtime;
	}
	public void setRegtime(String regtime) {
		this.regtime = regtime;
	}
}
