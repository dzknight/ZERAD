package main;

import java.util.ArrayList;
import java.util.Scanner;

public class CarM {
	//자동차를 관리
	//카원객체를 crud하는 책임
//	private CarOne [] carList=new CarOne[5];
	private ArrayList<CarOne> carList=new ArrayList<CarOne>();
	//mem val
	public ArrayList<CarOne> getCarList() {
		return carList;
	}
	public void setCarList(ArrayList<CarOne> carList) {
		this.carList = carList;
	}
	public void insertCar() {
		//객체의 정보를 입력받는다
		//카원의 객체를 의존하는데 생성하는 방법이 적당
		//카리스트 등록한다
		Scanner in =new Scanner(System.in);
		System.out.println("번호와 소유자를 차례대로 입력하세요");
		String num=in.nextLine();
		String username=in.nextLine();
		CarOne carone =new CarOne();
		carone.setNum(num);//세터를 이용한  값 주입
		carone.setUserName(username);//세터를 이용한 값 주입
//		for(int i=0;i<carList.length;i++) {
//			if(carList[i]==null) {
//				carList[i]=carone;
//				break;
//			}
//		}
		carList.add(carone);
	}
	public void listCar() {
		for(CarOne c :carList) {
//			if(c!=null) {
				c.prt();
//			}
		}
	}
	public void menu() {
		Scanner in= new Scanner(System.in);
		boolean flag=true;
		
		while(flag) {
			System.out.println("객체주소"+this.hashCode());
			System.out.println("1.차등록 2.전체보기");
			System.out.println("번호를 선택하세요");
			int a=in.nextInt();
			in.nextLine();
			switch (a) {
			case 1:
				insertCar();
				break;
			case 2:
				listCar();
				break;

			default:
				flag=false;
			}
			
			
		}
	}
}
