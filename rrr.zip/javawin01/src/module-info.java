/**
 * 
 */
/**
 * 
 */
module javawin11 {
	requires java.sql;
}