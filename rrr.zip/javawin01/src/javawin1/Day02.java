package javawin1;

public class Day02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//영수와 철수는 각각 기본점수 100선언
		int young=0;
		young=100;
		int cheol=0;
		cheol=100;
		
		//철수는 2번이겨 승점 20점을 얻었다
		cheol=cheol+10;
		cheol=cheol+10;
		//영수는 2번져서 점수 20점을 잃었다
		young=young-10;
		young=young-10;
		//비겨서 영수 철수 둘다 2점씩 얻었다
		cheol=cheol+2;
		young=young+2;
		//영수가 한번 이겼다
		young=young+10;
		
		System.out.println("영수는"+young+"이고 철수는"+cheol+"입니다");

		
				
	}

}
