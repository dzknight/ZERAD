package javawin1;

public class cntArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a ={34,55,23,56,34,45,34};
		int[] b ={36,49};
		int cnt=0;
		for(int i=0;i<b.length;i++) {
			cnt=0;
			for(int j=0;j<a.length;j++) {
				if(b[i]<a[j]) {
					cnt++;
				}
			}
			System.out.println("a배열"+cnt+"|"+b[i]);
		}
	}

}
