package coffee;

public class Menu {
	
	public String name;
	public int price;
	public String desc;
	
	public Menu(String name,int price,String desc){
		this.name=name;
		this.price=price;
		this.desc=desc;
	}



}
