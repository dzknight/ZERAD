package main;

public class BillMenu {
	
	MenuOne menu=null;
	int cnt=0;

}
