package javawin1;

public class beforeCharEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char beforeChar='z';
		beforeChar++;
		beforeChar++;
		//문자형 을 정수와 계산하며 묵시적으로 정수가 된다. 두자리 뒤의 문자이므로 아스키코드 영소문자자릿수인97을 빼고 2를 더한뒤 알파벳개수로 나머지를 구한다. 이후 다시 97을 더하여 영소문자를 나타낸다.
		//if 보정
		//97 변수와 연산자
		//
		//char afterchar=(char) ((beforeChar-97+2)%26+97);
		//char a=('z'-97+2)%26+97;
		char a=(char) (((beforeChar+2)%26)+97);
		char charNum=beforeChar;
		System.out.println((a));
	}

}
