package javawin1;

public class DigitSum987654321 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*987654321이라는 숫자가 있다.. 변수2개와 for문 한개로
		   모든 자릿수를 더한 합을 */
		   int sum=0;
		   for(int i=987654321;i>0;i=i/10) {
			   sum=sum+i%10;
		   }
		   System.out.println(sum);
	}
}
