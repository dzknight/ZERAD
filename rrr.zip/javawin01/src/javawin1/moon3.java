package javawin1;
import java.util.Scanner;

public class moon3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in= new Scanner(System.in);
		//Scanner qun= new Scanner(System.in);
		String[] menu ={"만두","라조기", "동파육","짜장면","짬뽕"} ;
		String [] menu_no={"2000","10000","20000","6000","7000"};//
		
		
		System.out.println("메뉴를 입력하세요 만두는1 라조기는2 동파육은3 짜장면4번 짬뽕5번 종료는999" );
		int temp =in.nextInt();
		for(int i=temp;i==temp;i++) {
			
			int cnt=i++;
			menu[i] =in.next();
			//menu_no[i] =in.nextLine();
			//System.out.println(menu_no[i]);
			System.out.println(menu[i-1]);
			
			System.out.println("주문횟수"+cnt+"입니다");
			
			//System.out.println("총가격은"+menu[i-1]);
		}
		System.out.println("가격을 입력하세요");
		
		int temp1 =in.nextInt();
		for(int i=temp1;i==temp1;i++) {
			menu_no[i-1]=in.next();
			System.out.println("가격"+menu_no[i]+"원");
		}
	}

}
