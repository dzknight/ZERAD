package javawin1;

public class doubleEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int b=10;
		int c=4;
		int d=b/c;
		double e=b/c;
		int g=b/c;
		double h=b/(double)c;
		System.out.println(e); //2.0
		System.out.println(g); //2
		System.out.println(h);	//2.5
	}
	/*
	 * b변수를 선언하고 자료형은 인트이다 초기갑상수 10을 대입하여 저장한다
	 * 초기값으로 b/c결과를 대입하여 저장한다 경과는 정수정수 연산이므로 결고겂운 2이다
	 * 
	 * 자료형은 작은형에서 큰형에 맞게 형변환이 일어난다
	 * 
	 * */
}
